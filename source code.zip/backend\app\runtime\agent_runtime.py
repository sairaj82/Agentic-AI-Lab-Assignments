import time
import datetime
from typing import Dict, Any, List, Optional, Callable
from app.tools.grant_tools import AVAILABLE_TOOLS
from app.skills.grant_skills import SKILL_REGISTRY
from app.memory.project_memory import project_memory

class AuditLogger:
    def __init__(self):
        self.logs: List[Dict[str, Any]] = []

    def record(self, stage: str, user: str, task: str, status: str, details: Any, error: Optional[str] = None):
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "stage": stage,
            "user": user,
            "task": task,
            "status": status,
            "details": details,
            "error": error
        }
        self.logs.append(entry)
        return entry

class OpenClawRuntime:
    """
    OpenClaw-style Agent Runtime adhering to the 6-layer architecture:
    1. Interface Layer
    2. Runtime Execution Loop
    3. Skill Registry
    4. Tool Registry
    5. Scoped Memory
    6. Audit Logging
    """
    def __init__(self):
        self.tools: Dict[str, Callable] = dict(AVAILABLE_TOOLS)
        self.skills: Dict[str, Any] = dict(SKILL_REGISTRY)
        self.memory = project_memory
        self.audit = AuditLogger()
        # Lab 6 Assignment 1: Per-user rate limiting (max 10 tasks per user per session)
        self.user_task_counts: Dict[str, int] = {}
        self.max_tasks_per_user: int = 10
        # Lab 6 Assignment 2: Consecutive failure escalation
        self.consecutive_failures: Dict[str, int] = {}

    def register_skill(self, name: str, skill_instance: Any):
        """Allows dynamic registration of skills without altering runtime loop."""
        self.skills[name] = skill_instance
        self.audit.record("skill_registry", "system", f"register_{name}", "SUCCESS", {"skill": name})

    def register_tool(self, name: str, tool_func: Callable):
        self.tools[name] = tool_func
        self.audit.record("tool_registry", "system", f"register_{name}", "SUCCESS", {"tool": name})

    def run_task(self, user: str, task_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        start_time = time.time()

        # Check Rate Limit (Lab 6 Assignment 1)
        current_count = self.user_task_counts.get(user, 0)
        if current_count >= self.max_tasks_per_user:
            err_msg = f"Rate limit exceeded: User '{user}' has reached maximum {self.max_tasks_per_user} tasks per session."
            self.audit.record("rate_limit", user, task_name, "BLOCKED", {"limit": self.max_tasks_per_user}, err_msg)
            return {"status": "BLOCKED", "error": err_msg, "execution_time_sec": round(time.time() - start_time, 3)}

        self.user_task_counts[user] = current_count + 1

        # Check Consecutive Failures Escalation (Lab 6 Assignment 2)
        failures = self.consecutive_failures.get(user, 0)
        if failures >= 2:
            escalation_msg = f"Escalation Triggered: User '{user}' encountered {failures} consecutive task failures. Directing task to Human Senior Administrator review."
            self.audit.record("escalation", user, task_name, "ESCALATED", {"consecutive_failures": failures}, escalation_msg)
            return {
                "status": "ESCALATED_TO_HUMAN",
                "reason": escalation_msg,
                "execution_time_sec": round(time.time() - start_time, 3)
            }

        self.audit.record("intake", user, task_name, "STARTED", {"payload_keys": list(payload.keys())})

        try:
            # Step 1: Select skill or tool
            target_skill = payload.get("skill")
            target_tool = payload.get("tool")

            if target_skill:
                if target_skill not in self.skills:
                    raise KeyError(f"Skill '{target_skill}' not found in registry.")
                skill_obj = self.skills[target_skill]
                result = skill_obj.execute(payload)
            elif target_tool:
                if target_tool not in self.tools:
                    raise KeyError(f"Tool '{target_tool}' not found in registry.")
                tool_fn = self.tools[target_tool]
                result = tool_fn(**payload.get("arguments", {}))
            else:
                # Default orchestrator behavior: evaluate grant topic
                result = self.skills["funding_evaluation"].execute(payload)

            # Record success in memory and audit
            self.memory.set_session(f"last_task_{user}", task_name)
            self.consecutive_failures[user] = 0 # reset failure count
            exec_time = round(time.time() - start_time, 3)
            self.audit.record("execution", user, task_name, "SUCCESS", {"execution_time_sec": exec_time})

            return {
                "status": "SUCCESS",
                "result": result,
                "execution_time_sec": exec_time,
                "user_session_tasks": self.user_task_counts[user]
            }

        except Exception as e:
            self.consecutive_failures[user] = self.consecutive_failures.get(user, 0) + 1
            exec_time = round(time.time() - start_time, 3)
            self.audit.record("execution", user, task_name, "FAILED", {"error": str(e)}, str(e))
            return {
                "status": "FAILED",
                "error": str(e),
                "consecutive_failures": self.consecutive_failures[user],
                "execution_time_sec": exec_time
            }

runtime = OpenClawRuntime()
