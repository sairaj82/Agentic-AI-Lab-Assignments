import pytest
from labs.week06.lab import run_lab_week06

def test_week06_execution():
    result = run_lab_week06()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 6

def test_week06_assignments():
    result = run_lab_week06()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 6 must contain at least 2 assignment outputs'
