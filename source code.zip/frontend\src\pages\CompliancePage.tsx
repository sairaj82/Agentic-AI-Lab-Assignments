import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, CheckCircle2, XCircle, FileWarning, Loader2, Award } from 'lucide-react';
import { api } from '../services/api';

export const CompliancePage: React.FC = () => {
  const [projectId, setProjectId] = useState<number>(1);
  const [running, setRunning] = useState(false);
  const [report, setReport] = useState<any>(null);

  const handleRunCheck = async () => {
    setRunning(true);
    try {
      const res = await api.runComplianceCheck(projectId);
      setReport(res);
    } catch (e: any) {
      alert(`Compliance audit error: ${e.message}`);
    }
    setRunning(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Compliance & Ethics Centre</h2>
          <p className="text-slate-500 text-sm mt-1">
            Automated verification of solicitation rules, eligibility criteria, ITAR/export controls, and ethics
          </p>
        </div>
        <button
          onClick={handleRunCheck}
          disabled={running}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
        >
          {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
          Run Compliance Audit
        </button>
      </div>

      {report ? (
        <div className="space-y-6">
          {/* Score Banner */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-5">
                <div
                  className={`w-20 h-20 rounded-2xl flex items-center justify-center font-extrabold text-3xl font-mono shadow-inner ${
                    (report.overall_score || 90) >= 85
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}
                >
                  {report.overall_score || 90}%
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-slate-900">Overall Compliance Status</h3>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                        (report.overall_score || 90) >= 85
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {(report.overall_score || 90) >= 85 ? 'READY FOR SIGN-OFF' : 'ACTION REQUIRED'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Evaluated against federal grant governance policies, institutional F&A agreements, and ethics boards.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 w-full md:w-auto">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-center min-w-[130px]">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Eligibility</span>
                  <p className="text-xs font-bold text-slate-800 mt-1 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> {report.eligibility_status || 'VERIFIED'}
                  </p>
                </div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-center min-w-[130px]">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Budget Cap</span>
                  <p className="text-xs font-bold text-slate-800 mt-1 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> {report.budget_status || 'IN_BOUNDS'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Missing Documents */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <FileWarning className="w-4 h-4 text-amber-500" /> Required Documentation
              </h4>
              {report.missing_documents && report.missing_documents.length > 0 ? (
                <div className="space-y-2">
                  {report.missing_documents.map((doc: string, i: number) => (
                    <div key={i} className="text-xs text-amber-900 bg-amber-50 p-2.5 rounded-lg border border-amber-200 flex items-start gap-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span>{doc}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-emerald-800 bg-emerald-50 p-3 rounded-lg border border-emerald-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> All mandatory files present.
                </div>
              )}
            </div>

            {/* Ethics & ITAR */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-blue-500" /> IRB / Ethics & Security
              </h4>
              <div className="text-xs space-y-2">
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-600">Ethics Approval:</span>
                  <span className="font-semibold text-slate-900">
                    {report.ethics_approval_needed ? 'IRB Protocol Required' : 'Exempt (Computational)'}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-600">ITAR / Export Control:</span>
                  <span className="font-semibold text-emerald-700">Clear (Fundamental Research)</span>
                </div>
              </div>
            </div>

            {/* Warnings */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" /> Compliance Warnings
              </h4>
              {report.warnings && report.warnings.length > 0 ? (
                <div className="space-y-1.5">
                  {report.warnings.map((w: string, i: number) => (
                    <p key={i} className="text-xs text-slate-700 flex items-start gap-1.5">
                      <span className="text-rose-500 font-bold">•</span>
                      <span>{w}</span>
                    </p>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No warnings issued by compliance agent.</p>
              )}
            </div>
          </div>

          {/* Audit Narrative */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Compliance Agent Audit Narrative</h4>
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 font-mono whitespace-pre-wrap leading-relaxed max-h-64 overflow-auto">
              {report.check_report || JSON.stringify(report, null, 2)}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <ShieldCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-slate-700">No Compliance Audit on Record</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
            Click "Run Compliance Audit" above to dispatch the Compliance Agent to verify solicitation rules, budget caps, and required documentation.
          </p>
        </div>
      )}
    </div>
  );
};
