import time
from typing import Dict, Any, List
from app.tools.grant_tools import tool_calculate_budget
from app.skills.grant_skills import SKILL_REGISTRY

class BudgetPlanningAgent:
    """
    Agent 4: Budget Planning Agent
    Produces OUTPUT 3: Budget Plan.
    Calculates costs across standard grant categories:
    - Personnel costs
    - Equipment costs
    - Computing and software costs
    - Travel costs
    - Other eligible expenses (indirect facilities & administrative, consumables)
    - Category-wise allocation breakdown
    - Total budget
    - Budget justification narrative
    Supports dynamic recalculation when requirements change.
    """
    def __init__(self):
        self.name = "Budget Planning Agent"
        self.status = "IDLE"

    def execute(self, project_id: int = 1, target_opportunity_amount: float = 750000.0, custom_items: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.status = "WORKING"
        start_time = time.time()

        items = custom_items if custom_items and len(custom_items) > 0 else [
            {
                "category": "Personnel",
                "description": "Graduate Research Assistant (2 PhD students, 24 months)",
                "quantity": 2,
                "unit_cost": 36000.0,
                "total_cost": 72000.0,
                "justification": "Primary student researchers executing algorithm development, theorem formulation, and benchmark experiments."
            },
            {
                "category": "Equipment",
                "description": "High-Throughput Edge AI & GPU Computing Server (4x RTX 6000 Ada)",
                "quantity": 4,
                "unit_cost": 9500.0,
                "total_cost": 38000.0,
                "justification": "Local neural training testbed and sub-millisecond hardware-in-the-loop latency evaluation."
            },
            {
                "category": "Computing & Software",
                "description": "Cloud Vector DB, Cluster Orchestration & Scientific Software Licenses",
                "quantity": 1,
                "unit_cost": 12000.0,
                "total_cost": 12000.0,
                "justification": "Telemetry storage, distributed ray cluster compute time, and formal solver verification tools."
            },
            {
                "category": "Travel",
                "description": "Conference Dissemination (NeurIPS, ICRA, AAMAS conferences)",
                "quantity": 3,
                "unit_cost": 3000.0,
                "total_cost": 9000.0,
                "justification": "Presentation of peer-reviewed grant research findings to international peer reviewers."
            },
            {
                "category": "Other Eligible Expenses",
                "description": "Open Access Publishing Fees, Lab Consumables & Datasets",
                "quantity": 1,
                "unit_cost": 6500.0,
                "total_cost": 6500.0,
                "justification": "Mandatory federal requirement for open access public dissemination and archival indexing."
            },
            {
                "category": "Indirect Costs",
                "description": "Federally Negotiated Institutional Facilities & Administrative Overhead (26%)",
                "quantity": 1,
                "unit_cost": 35750.0,
                "total_cost": 35750.0,
                "justification": "Institutional indirect cost recovery capped at university negotiated 26% direct cost basis."
            }
        ]

        # 1. Calculate budget totals and ceiling limits using validated tool
        calc_res = tool_calculate_budget(items, max_limit=target_opportunity_amount)

        # 2. Write narrative justification using skill
        just_skill = SKILL_REGISTRY["budget_justification"]
        just_res = just_skill.execute({"items": items})

        # Structured Category-wise breakdown
        category_breakdown = {
            "personnel_costs": sum(i["total_cost"] for i in items if i["category"] == "Personnel"),
            "equipment_costs": sum(i["total_cost"] for i in items if i["category"] == "Equipment"),
            "computing_software_costs": sum(i["total_cost"] for i in items if "comput" in i["category"].lower() or "soft" in i["category"].lower()),
            "travel_costs": sum(i["total_cost"] for i in items if i["category"] == "Travel"),
            "other_eligible_expenses": sum(i["total_cost"] for i in items if i["category"] in ["Other Eligible Expenses", "Consumables", "Indirect Costs", "Indirect"]),
            "indirect_costs": sum(i["total_cost"] for i in items if "indirect" in i["category"].lower())
        }

        total_budget = sum(i["total_cost"] for i in items)

        self.status = "IDLE"
        elapsed = round(time.time() - start_time, 3)

        return {
            "agent": self.name,
            "status": "SUCCESS",
            "project_id": project_id,
            "items": items,
            "category_breakdown": category_breakdown,
            "total_budget": total_budget,
            "budget_calculation": calc_res,
            "justification_narrative": just_res["narrative"],
            "within_limit": total_budget <= target_opportunity_amount,
            "target_opportunity_amount": target_opportunity_amount,
            "execution_time_sec": elapsed
        }

budget_agent = BudgetPlanningAgent()
