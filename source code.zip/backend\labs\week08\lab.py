import json
from typing import Dict, Any, List
from app.workflows.parallel_swarm import ParallelGrantSwarm

def run_lab_week08() -> Dict[str, Any]:
    swarm = ParallelGrantSwarm()

    # 1. Normal concurrent swarm run (5 specialist roles executing concurrently)
    normal_swarm_res = swarm.execute_swarm(
        topic="Decentralized cyber-physical swarm verification",
        domain="Computer Science",
        requested_budget=157500.0,
        pi_tenure=True
    )

    # 2. Assignment 2: Swarm run with conflicting budget recommendations & resolution
    # Setting requested_budget very close to cap to trigger margin conflict
    conflict_budget_swarm_res = swarm.execute_swarm(
        topic="Extreme High-Voltage Grid Fault Tolerant Inverters",
        domain="Electrical Engineering",
        requested_budget=745000.0, # > 95% of 750,000 cap
        pi_tenure=True
    )

    # 3. Assignment 1: 5th specialist role (Impact & Ethics Specialist)
    # Check ethics agent output in normal run
    ethics_res = next(r for r in normal_swarm_res["agent_results"] if r["role"] == "Impact & Ethics Specialist Agent")

    return {
        "week": 8,
        "title": "Lab 8: Parallel Agent Swarm -- Concurrent Execution, Structured Merging & Conflict Resolution",
        "swarm_roles": swarm.roles,
        "concurrent_execution_mode": normal_swarm_res["execution_mode"],
        "normal_run": {
            "total_execution_time_sec": normal_swarm_res["total_execution_time_sec"],
            "agent_results_count": len(normal_swarm_res["agent_results"]),
            "agent_roles_executed": [r["role"] for r in normal_swarm_res["agent_results"]],
            "conflicts_detected": normal_swarm_res["conflicts_detected"],
            "final_recommendation": normal_swarm_res["final_ranked_recommendation"]
        },
        "assignment_1_fifth_role_ethics_specialist": {
            "role_name": "Impact & Ethics Specialist Agent",
            "findings": ethics_res,
            "passed": ethics_res is not None
        },
        "assignment_2_conflict_resolution": {
            "conflict_run_results": conflict_budget_swarm_res["conflicts_detected"],
            "conflict_detected_and_resolved": len(conflict_budget_swarm_res["conflicts_detected"]) > 0,
            "resolution_details": conflict_budget_swarm_res["conflicts_detected"][0] if conflict_budget_swarm_res["conflicts_detected"] else None
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week08()
    print(json.dumps(result, indent=2))
