import pytest
from app.agents.funding_discovery.agent import funding_agent
from app.agents.literature_review.agent import literature_agent
from app.agents.proposal_drafting.agent import proposal_agent
from app.agents.budget_planning.agent import budget_agent
from app.agents.compliance_checking.agent import compliance_agent
from app.agents.submission.agent import submission_agent
from app.workflows.node_graph import grant_node_graph
from app.workflows.parallel_swarm import grant_swarm

def test_full_agent_lifecycle_integration():
    topic = 'Decentralized Cyber-Physical Multi-Agent Verification'
    domain = 'Computer Science'
    
    # 1. Funding
    f_res = funding_agent.execute(topic, domain)
    assert f_res['status'] == 'SUCCESS'
    assert f_res['matched_count'] > 0

    # 2. Literature
    l_res = literature_agent.execute(topic)
    assert l_res['status'] == 'SUCCESS'
    assert len(l_res['identified_gaps']) > 0

    # 3. Proposal
    p_res = proposal_agent.execute(topic, domain, gaps=l_res['identified_gaps'])
    assert p_res['status'] == 'SUCCESS'
    assert len(p_res['objectives']) >= 3

    # 4. Budget
    b_res = budget_agent.execute(project_id=1, target_opportunity_amount=750000.0)
    assert b_res['status'] == 'SUCCESS'
    assert b_res['within_limit'] is True

    # 5. Compliance
    c_res = compliance_agent.execute(project_id=1, proposal_data=p_res, budget_data=b_res)
    assert c_res['status'] == 'SUCCESS'
    assert c_res['overall_score'] >= 80.0

    # 6. Submission
    pkg = submission_agent.assemble_package(project_id=1, proposal_data=p_res, budget_data=b_res, compliance_data=c_res)
    assert pkg['ready_for_faculty_approval'] is True

    s_res = submission_agent.execute_submission(project_id=1, package=pkg, faculty_approved=True)
    assert s_res['status'] == 'SUBMITTED'
    assert 'NSF-FASTLANE' in s_res['tracking_number']

def test_node_graph_and_swarm_integration():
    topic = 'Decentralized Swarms'
    domain = 'Computer Science'

    # Graph
    g_res = grant_node_graph.execute_graph(topic, domain, 157500.0, True)
    assert g_res['graph_status'] == 'SUCCESS'
    assert g_res['total_nodes_executed'] == 9

    # Swarm
    sw_res = grant_swarm.execute_swarm(topic, domain, 157500.0, True)
    assert sw_res['status'] == 'SUCCESS'
    assert sw_res['swarm_size'] == 5
