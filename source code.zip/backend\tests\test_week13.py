import pytest
from labs.week13.lab import run_lab_week13

def test_week13_execution():
    result = run_lab_week13()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 13

def test_week13_assignments():
    result = run_lab_week13()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 13 must contain at least 2 assignment outputs'
