import pytest
from labs.week03.lab import run_lab_week03

def test_week03_execution():
    result = run_lab_week03()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 3

def test_week03_assignments():
    result = run_lab_week03()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 3 must contain at least 2 assignment outputs'
