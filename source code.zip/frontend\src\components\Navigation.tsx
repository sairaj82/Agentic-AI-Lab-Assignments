import React from 'react';
import { 
  LayoutDashboard, 
  Bot, 
  Search, 
  FileText, 
  PenTool, 
  DollarSign, 
  ShieldCheck, 
  Send, 
  GraduationCap, 
  GitFork,
  Activity,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface NavigationProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  systemStatus: any;
}

export const Navigation: React.FC<NavigationProps> = ({ currentTab, setCurrentTab, systemStatus }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Main Dashboard', icon: LayoutDashboard },
    { id: 'agents', label: 'AI Agents Dashboard', icon: Bot, badge: '6 Active' },
    { id: 'opportunities', label: 'Grant Opportunities', icon: Search },
    { id: 'research', label: 'Research Workspace', icon: FileText },
    { id: 'proposals', label: 'Proposal Workspace', icon: PenTool },
    { id: 'budget', label: 'Budget Planner', icon: DollarSign },
    { id: 'compliance', label: 'Compliance Centre', icon: ShieldCheck },
    { id: 'submission', label: 'Submission Centre', icon: Send },
    { id: 'workflow', label: 'Agent Workflow Graph', icon: GitFork, badge: 'React Flow' },
    { id: 'labs', label: '14-Week Lab Progress', icon: GraduationCap, badge: '14/14' },
  ];

  return (
    <aside className="w-72 bg-navy-950 text-white flex flex-col h-screen fixed left-0 top-0 z-30 border-r border-navy-850 shadow-xl">
      {/* Brand Header */}
      <div className="p-6 border-b border-navy-850">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/30">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
              GrantAgent <span className="text-xs px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-semibold border border-blue-500/30">AI</span>
            </h1>
            <p className="text-xs text-slate-400">Research Grant Platform</p>
          </div>
        </div>

        {/* System Mode Indicator */}
        <div className="mt-4 px-3 py-2 rounded-lg bg-navy-900/80 border border-navy-800 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <span className={`w-2 h-2 rounded-full ${systemStatus?.llm_status?.mode === 'real_llm' ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
            <span className="text-slate-300 font-medium">
              {systemStatus?.llm_status?.mode === 'real_llm' ? 'OpenAI GPT-4o' : 'Offline Heuristics'}
            </span>
          </div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider">
            {systemStatus?.llm_status?.mode === 'real_llm' ? 'LIVE' : 'DEMO'}
          </span>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-1.5">
        <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
          Autonomous Lifecycle
        </div>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-semibold'
                  : 'text-slate-300 hover:bg-navy-900 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                  isActive ? 'bg-blue-800 text-white' : 'bg-navy-850 text-slate-300 border border-navy-800'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User / Faculty Profile Footer */}
      <div className="p-4 border-t border-navy-850 bg-navy-900/60">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-full bg-blue-900 text-blue-200 border border-blue-700/50 flex items-center justify-center font-bold text-xs">
            AT
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white truncate">Dr. Aris Thorne</p>
            <p className="text-[11px] text-slate-400 truncate">Computer Science & Eng.</p>
          </div>
        </div>
      </div>
    </aside>
  );
};
