import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database.session import Base

class Faculty(Base):
    __tablename__ = "faculty"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    department = Column(String(100), nullable=False)
    research_domain = Column(String(100), nullable=False) # e.g. Computer Science, Mechanical, Civil, Electrical
    bio = Column(Text, nullable=True)

    projects = relationship("ResearchProject", back_populates="faculty", cascade="all, delete-orphan")

class GrantOpportunity(Base):
    __tablename__ = "grant_opportunities"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    agency = Column(String(100), nullable=False) # e.g. NSF, NIH, DOE, DARPA, SERB
    amount = Column(Float, nullable=False)
    deadline = Column(String(50), nullable=False)
    domain = Column(String(100), nullable=False) # Computer Science, Electrical, Mechanical, Civil, Interdisciplinary
    eligibility = Column(Text, nullable=False)
    description = Column(Text, nullable=False)
    url = Column(String(255), nullable=True)
    status = Column(String(50), default="Open") # Open, Upcoming, Closed
    relevance_score = Column(Float, default=0.0)

class ResearchProject(Base):
    __tablename__ = "research_projects"

    id = Column(Integer, primary_key=True, index=True)
    faculty_id = Column(Integer, ForeignKey("faculty.id"), nullable=True)
    title = Column(String(200), nullable=False)
    domain = Column(String(100), default="Computer Science")
    topic = Column(String(255), nullable=False)
    abstract = Column(Text, nullable=True)
    status = Column(String(50), default="Drafting") # Discovery, Drafting, Budgeting, Compliance, Ready, Submitted
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    faculty = relationship("Faculty", back_populates="projects")
    documents = relationship("ResearchDocument", back_populates="project", cascade="all, delete-orphan")
    proposals = relationship("ProposalDraft", back_populates="project", cascade="all, delete-orphan")
    budget_items = relationship("BudgetItem", back_populates="project", cascade="all, delete-orphan")
    compliance_checks = relationship("ComplianceCheck", back_populates="project", cascade="all, delete-orphan")
    submissions = relationship("SubmissionRecord", back_populates="project", cascade="all, delete-orphan")

class ResearchDocument(Base):
    __tablename__ = "research_documents"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("research_projects.id"), nullable=False)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(50), default="paper") # paper, guideline, institutional
    file_path = Column(String(255), nullable=False)
    extracted_text = Column(Text, nullable=True)
    chunk_count = Column(Integer, default=0)
    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)

    project = relationship("ResearchProject", back_populates="documents")

class ProposalDraft(Base):
    __tablename__ = "proposal_drafts"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("research_projects.id"), nullable=False)
    version = Column(Integer, default=1)
    title = Column(String(255), nullable=False)
    abstract = Column(Text, nullable=True)
    introduction = Column(Text, nullable=True)
    problem_statement = Column(Text, nullable=True)
    objectives = Column(JSON, nullable=True) # list of string objectives
    literature_review = Column(Text, nullable=True)
    research_gap = Column(Text, nullable=True)
    methodology = Column(Text, nullable=True)
    expected_outcomes = Column(JSON, nullable=True)
    research_significance = Column(Text, nullable=True)
    references = Column(JSON, nullable=True) # list of reference strings
    full_draft = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    project = relationship("ResearchProject", back_populates="proposals")

class BudgetItem(Base):
    __tablename__ = "budget_items"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("research_projects.id"), nullable=False)
    category = Column(String(50), nullable=False) # Personnel, Equipment, Travel, Consumables, Indirect, Miscellaneous
    description = Column(String(255), nullable=False)
    quantity = Column(Integer, default=1)
    unit_cost = Column(Float, nullable=False)
    total_cost = Column(Float, nullable=False)
    justification = Column(Text, nullable=True)

    project = relationship("ResearchProject", back_populates="budget_items")

class ComplianceCheck(Base):
    __tablename__ = "compliance_checks"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("research_projects.id"), nullable=False)
    overall_score = Column(Float, default=100.0) # 0 to 100
    eligibility_status = Column(String(50), default="Passed")
    budget_status = Column(String(50), default="Passed")
    missing_documents = Column(JSON, default=list)
    ethics_approval_needed = Column(Boolean, default=False)
    warnings = Column(JSON, default=list)
    check_report = Column(Text, nullable=True)
    checked_at = Column(DateTime, default=datetime.datetime.utcnow)

    project = relationship("ResearchProject", back_populates="compliance_checks")

class SubmissionRecord(Base):
    __tablename__ = "submission_records"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("research_projects.id"), nullable=False)
    package_json = Column(JSON, nullable=False)
    checklist = Column(JSON, default=list)
    faculty_approved = Column(Boolean, default=False)
    approved_by = Column(String(100), nullable=True)
    submission_timestamp = Column(DateTime, nullable=True)
    tracking_number = Column(String(100), nullable=True)
    status = Column(String(50), default="Pending Review") # Pending Review, Approved, Submitted, Rejected

    project = relationship("ResearchProject", back_populates="submissions")

class AgentExecutionLog(Base):
    __tablename__ = "agent_execution_logs"

    id = Column(Integer, primary_key=True, index=True)
    agent_name = Column(String(100), nullable=False)
    task_name = Column(String(150), nullable=False)
    project_id = Column(Integer, nullable=True)
    input_payload = Column(JSON, nullable=True)
    output_payload = Column(JSON, nullable=True)
    status = Column(String(50), default="SUCCESS") # SUCCESS, FAILED, RUNNING
    execution_time_sec = Column(Float, default=0.0)
    error_details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class LabRecord(Base):
    __tablename__ = "lab_records"

    id = Column(Integer, primary_key=True, index=True)
    week_number = Column(Integer, unique=True, nullable=False)
    lab_title = Column(String(150), nullable=False)
    objective = Column(Text, nullable=False)
    implementation_summary = Column(Text, nullable=False)
    test_results = Column(JSON, default=list)
    assignment_1_result = Column(JSON, default=dict)
    assignment_2_result = Column(JSON, default=dict)
    sample_input = Column(JSON, default=dict)
    sample_output = Column(JSON, default=dict)
    execution_trace = Column(JSON, default=list)
    completed = Column(Boolean, default=False)
    run_timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class LabExecutionHistory(Base):
    __tablename__ = "lab_execution_history"

    id = Column(Integer, primary_key=True, index=True)
    week_number = Column(Integer, nullable=False, index=True)
    lab_title = Column(String(150), nullable=False)
    input_payload = Column(JSON, default=dict)
    output_payload = Column(JSON, default=dict)
    status = Column(String(50), default="SUCCESS")
    execution_time_sec = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class GrantPlanningSession(Base):
    __tablename__ = "grant_planning_sessions"

    id = Column(Integer, primary_key=True, index=True)
    faculty_name = Column(String(100), default="Dr. Aris Thorne")
    objective = Column(Text, nullable=False)
    domain = Column(String(100), nullable=True)
    target_agency = Column(String(100), nullable=True)
    missing_info = Column(JSON, default=list)
    clarification_questions = Column(JSON, default=list)
    clarification_responses = Column(JSON, default=dict)
    prompt_logs = Column(JSON, default=list)
    initial_plan = Column(JSON, default=dict)
    assumptions = Column(JSON, default=list)
    conflicts_detected = Column(JSON, default=list)
    faculty_feedback = Column(Text, nullable=True)
    revised_plan = Column(JSON, default=dict)
    revision_delta = Column(JSON, default=list)
    reasoning_summary = Column(Text, nullable=True)
    execution_trace = Column(JSON, default=list)
    reflection = Column(Text, nullable=True)
    status = Column(String(50), default="ANALYZED") # ANALYZED, PLAN_GENERATED, REVISED
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

