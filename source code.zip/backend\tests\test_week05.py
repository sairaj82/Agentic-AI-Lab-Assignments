import pytest
from labs.week05.lab import run_lab_week05

def test_week05_execution():
    result = run_lab_week05()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 5

def test_week05_assignments():
    result = run_lab_week05()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 5 must contain at least 2 assignment outputs'
