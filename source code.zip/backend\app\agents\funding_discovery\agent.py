import time
from typing import Dict, Any, List
from app.tools.grant_tools import tool_search_funding
from app.skills.grant_skills import SKILL_REGISTRY

class FundingDiscoveryAgent:
    """
    Agent 1: Funding Discovery Agent
    Discovers, scores, and ranks funding opportunities matching faculty research profile.
    Produces OUTPUT 1: Ranked Funding Opportunities with all official metadata:
    - Ranking
    - Funding Organization
    - Opportunity Title
    - Funding Amount
    - Eligibility
    - Deadline
    - Research Relevance Score
    - Reason for Recommendation
    - Source Link
    """
    def __init__(self):
        self.name = "Funding Discovery Agent"
        self.status = "IDLE"

    def execute(self, topic: str, domain: str = "Computer Science", max_budget: float = 1000000.0) -> Dict[str, Any]:
        self.status = "WORKING"
        start_time = time.time()
        
        # 1. Search database via tool
        search_res = tool_search_funding(topic, domain, max_budget)
        opportunities = search_res.get("opportunities", [])

        # 2. Score with funding evaluation skill
        eval_skill = SKILL_REGISTRY["funding_evaluation"]
        ranked = []
        for opp in opportunities:
            eval_out = eval_skill.execute({"topic": topic, "opportunity": opp})
            score = eval_out.get("relevance_score", opp.get("relevance_score", 50.0))
            rec = eval_out.get("recommendation", "MODERATE_FIT")
            
            # Format clean reason for recommendation
            agency = opp.get("agency", "Federal Agency")
            title = opp.get("title", "")
            reason = (
                f"Strong topical alignment with {agency}'s current priority in {domain}. "
                f"The budget ceiling of ${float(opp.get('amount', 0)):,.0f} accommodates equipment and personnel expenses."
            )

            ranked.append({
                "id": opp.get("id"),
                "ranking": 1, # will be populated after sort
                "funding_organization": agency,
                "agency": agency,
                "funding_opportunity_title": title,
                "title": title,
                "funding_amount": opp.get("amount", 500000.0),
                "amount": opp.get("amount", 500000.0),
                "eligibility": opp.get("eligibility", "Faculty PI with active tenure-track appointment."),
                "deadline": opp.get("deadline", "2026-12-15"),
                "relevance_score": min(100.0, max(50.0, score)),
                "reason_for_recommendation": reason,
                "recommendation": rec,
                "source_link": opp.get("url") or f"https://www.grants.gov/search-results-detail/{opp.get('id', 101)}",
                "url": opp.get("url") or f"https://www.grants.gov/search-results-detail/{opp.get('id', 101)}",
                "domain": opp.get("domain", domain),
                "compliance_flags": eval_out.get("compliance_flags", [])
            })

        # Sort dynamically by relevance score descending
        ranked.sort(key=lambda x: x["relevance_score"], reverse=True)
        for idx, item in enumerate(ranked, 1):
            item["ranking"] = idx

        self.status = "IDLE"
        elapsed = round(time.time() - start_time, 3)

        return {
            "agent": self.name,
            "status": "SUCCESS",
            "topic": topic,
            "domain": domain,
            "matched_count": len(ranked),
            "ranked_opportunities": ranked,
            "top_match": ranked[0] if ranked else None,
            "execution_time_sec": elapsed
        }

funding_agent = FundingDiscoveryAgent()
