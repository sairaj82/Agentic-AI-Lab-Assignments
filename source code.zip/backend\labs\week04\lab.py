import json
import time
from typing import Dict, Any, List
from app.memory.project_memory import ProjectMemoryStore

def run_lab_week04() -> Dict[str, Any]:
    memory = ProjectMemoryStore()

    # 1. Short-term session memory
    memory.set_session("current_user", "Dr. Aris Thorne")
    memory.set_session("active_grant_tab", "Budget Planner")

    # 2. Assignment 1: Scoped isolated memory for distinct research topics
    # Topic 1: Cyber-Physical Multi-Agent Consensus
    ns1 = "cyber_physical_systems"
    memory.record_fact(
        key="target_funding_agency",
        value="NSF CPS Frontier Program",
        source="Solicitation Portal NSF-24-580",
        topic_namespace=ns1,
        ttl_days=180
    )
    memory.record_fact(
        key="max_indirect_rate",
        value=0.26,
        source="University Negotiated Overhead Agreement 2026",
        topic_namespace=ns1,
        ttl_days=365
    )

    # Topic 2: Smart Grid Renewable Microgrids (Isolated from Topic 1)
    ns2 = "smart_grid_renewables"
    memory.record_fact(
        key="target_funding_agency",
        value="DOE EERE Grid Modernization",
        source="Department of Energy DE-FOA-0002998",
        topic_namespace=ns2,
        ttl_days=90
    )
    memory.record_fact(
        key="cost_share_required",
        value=0.20,
        source="DOE Cost Share Guideline CFR 200.306",
        topic_namespace=ns2,
        ttl_days=90
    )

    # 3. Source-tagged retrieval from both namespaces
    topic1_facts = memory.retrieve_all_for_topic(ns1)
    topic2_facts = memory.retrieve_all_for_topic(ns2)

    # 4. Conflict detection test: Update max_indirect_rate with different value
    conflict_result = memory.record_fact(
        key="max_indirect_rate",
        value=0.28,
        source="Proposed Sub-award Revision Draft",
        topic_namespace=ns1,
        ttl_days=180
    )

    # 5. Assignment 2: Memory Staleness Policy & TTL Retention
    # Insert an intentionally expired memory record (TTL 0 days)
    memory.record_fact(
        key="obsolete_preliminary_budget",
        value=50000.0,
        source="Initial 2025 Brainstorm Note",
        topic_namespace=ns1,
        ttl_days=0 # Stale immediately
    )
    # Check staleness before pruning
    stale_rec = memory.retrieve("obsolete_preliminary_budget", ns1)
    
    # Prune stale records with threshold 0 days
    prune_res = memory.prune_stale_records(max_days=0, topic_namespace=ns1)

    return {
        "week": 4,
        "title": "Lab 4: Memory and Retrieval -- Multi-Session Scoped Storage & Staleness Policies",
        "session_memory": memory.session_state,
        "assignment_1_isolated_namespaces": {
            "topic_1_namespace": ns1,
            "topic_1_records": topic1_facts,
            "topic_2_namespace": ns2,
            "topic_2_records": topic2_facts,
            "isolation_verified": len(topic1_facts) > 0 and len(topic2_facts) > 0 and topic1_facts[0]["value"] != topic2_facts[0]["value"]
        },
        "conflict_detection": {
            "conflict_logged": conflict_result["conflict_logged"],
            "updated_record": conflict_result["record"]
        },
        "assignment_2_staleness_policy": {
            "stale_record_detected_before_prune": stale_rec is not None and stale_rec.get("is_stale"),
            "pruning_report": prune_res,
            "retained_count_after_prune": len(memory.retrieve_all_for_topic(ns1))
        },
        "mutation_audit_log": memory.mutation_log,
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week04()
    print(json.dumps(result, indent=2))
