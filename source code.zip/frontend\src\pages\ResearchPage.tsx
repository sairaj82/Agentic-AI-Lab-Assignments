import React, { useState, useEffect } from 'react';
import { FileText, Upload, Search, Loader2, BookOpen, AlertTriangle, CheckCircle2, Plus, X } from 'lucide-react';
import { api } from '../services/api';

export const ResearchPage: React.FC = () => {
  const [topic, setTopic] = useState('Verifiable Cyber-Physical Swarms with Formal Guarantees');
  const [projects, setProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState<number>(1);
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<any>(null);
  const [reviewing, setReviewing] = useState(false);
  const [reviewResult, setReviewResult] = useState<any>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newProject, setNewProject] = useState({
    title: '',
    domain: 'Computer Science',
    topic: '',
    abstract: ''
  });

  useEffect(() => {
    api.getProjects().then(p => {
      setProjects(p);
      if (p.length > 0) setSelectedProject(p[0].id);
    }).catch(() => {});
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await api.uploadDocument(selectedProject, file);
      setUploadResult(res);
    } catch (err: any) {
      setUploadResult({ error: err.message });
    }
    setUploading(false);
  };

  const handleReview = async () => {
    if (!topic.trim()) return;
    setReviewing(true);
    try {
      const res = await api.runLiteratureReview(
        selectedProject,
        topic,
        uploadResult?.extracted_preview || ''
      );
      setReviewResult(res);
    } catch (err: any) {
      setReviewResult({ error: err.message });
    }
    setReviewing(false);
  };

  const handleCreateProject = async () => {
    try {
      await api.createProject({ ...newProject, faculty_id: 1 });
      const p = await api.getProjects();
      setProjects(p);
      setShowCreate(false);
      setNewProject({ title: '', domain: 'Computer Science', topic: '', abstract: '' });
    } catch {}
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Research Workspace</h2>
          <p className="text-slate-500 text-sm mt-1">
            Ingest research papers, synthesize scientific literature, and identify unaddressed gaps with RAG
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition shadow-sm"
        >
          <Plus className="w-4 h-4" /> New Research Project
        </button>
      </div>

      {/* Project Selector Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex items-center gap-4">
        <label className="text-sm font-semibold text-slate-700 whitespace-nowrap">Active Project Context:</label>
        <select
          value={selectedProject}
          onChange={e => setSelectedProject(Number(e.target.value))}
          className="flex-1 px-4 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          {projects.map((p: any) => (
            <option key={p.id} value={p.id}>{p.title} — [{p.domain}]</option>
          ))}
          {projects.length === 0 && <option value={1}>Default Seeded Project (ID 1)</option>}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Topic Input & Synthesis Request */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Research Topic & Scope</h3>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-600">Primary Research Topic</label>
            <input
              type="text"
              placeholder="e.g. Multi-Agent Systems for Resilient Grid Architecture"
              value={topic}
              onChange={e => setTopic(e.target.value)}
              className="w-full mt-1 px-4 py-2.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
            />
          </div>
          <button
            onClick={handleReview}
            disabled={reviewing || !topic.trim()}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
          >
            {reviewing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Synthesizing Literature (RAG)...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" /> Synthesize Literature Review
              </>
            )}
          </button>
        </div>

        {/* PDF Document Extraction */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Ingest Reference Paper (PDF)</h3>
          </div>
          <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:bg-slate-50 transition">
            {uploading ? (
              <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
            ) : (
              <>
                <FileText className="w-8 h-8 text-slate-400 mb-2" />
                <span className="text-sm font-medium text-slate-600">Upload PDF for PyMuPDF / RAG indexing</span>
                <span className="text-xs text-slate-400 mt-0.5">Automated chunking & source tier attribution</span>
              </>
            )}
            <input type="file" accept=".pdf" onChange={handleUpload} className="hidden" />
          </label>
          {uploadResult && (
            <div
              className={`p-3.5 rounded-lg text-xs ${
                uploadResult.error ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              }`}
            >
              {uploadResult.error ? (
                <>
                  <AlertTriangle className="w-4 h-4 inline mr-1 text-red-600" />
                  {uploadResult.error}
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 inline mr-1 text-emerald-600" />
                  Indexed <strong>{uploadResult.filename}</strong> ({uploadResult.chunk_count} semantic chunks ingested)
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Review Results */}
      {reviewResult && !reviewResult.error && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900">Literature Synthesis Report</h3>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 font-semibold border border-blue-100">
              Generated by Literature Review Agent
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-xs font-bold text-blue-800 uppercase tracking-wider mb-2">Synthesis Narrative</h4>
              <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                {reviewResult.synthesis || reviewResult.synthesis_narrative || JSON.stringify(reviewResult, null, 2)}
              </p>
            </div>
            <div className="p-4 bg-amber-50/70 rounded-xl border border-amber-200">
              <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-2">Identified Research Gaps</h4>
              {Array.isArray(reviewResult.gaps) ? (
                <div className="space-y-1.5">
                  {reviewResult.gaps.map((g: string, i: number) => (
                    <p key={i} className="text-xs text-amber-900 flex items-start gap-1.5">
                      <span className="font-bold text-amber-700">•</span>
                      <span>{g}</span>
                    </p>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-amber-900">{JSON.stringify(reviewResult.gaps || reviewResult.gap_analysis)}</p>
              )}
            </div>
          </div>

          {reviewResult.evidence_sources && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Referenced Scientific Evidence ({reviewResult.evidence_sources.length} Sources)
              </h4>
              <div className="space-y-1.5">
                {reviewResult.evidence_sources.map((s: any, i: number) => (
                  <div key={i} className="text-xs text-slate-600 flex items-center justify-between py-1 border-b border-slate-100 last:border-0">
                    <span className="truncate max-w-[80%]">
                      [{i + 1}] {typeof s === 'string' ? s : s.title || s.source || JSON.stringify(s)}
                    </span>
                    {s.tier && (
                      <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-semibold">
                        {s.tier}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {reviewResult.contradictions && reviewResult.contradictions.length > 0 && (
            <div className="p-4 bg-red-50 rounded-xl border border-red-200">
              <h4 className="text-xs font-bold text-red-800 uppercase tracking-wider mb-2">Contradictory Claims Detected</h4>
              <div className="space-y-1">
                {reviewResult.contradictions.map((c: any, i: number) => (
                  <p key={i} className="text-xs text-red-700 flex items-start gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 mt-0.5 text-red-600 shrink-0" />
                    <span>{typeof c === 'string' ? c : JSON.stringify(c)}</span>
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal for Creating New Project */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-900">New Research Project</h3>
              <button onClick={() => setShowCreate(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-600">Project Title</label>
                <input
                  type="text"
                  placeholder="e.g. Distributed Cyber-Physical Verification"
                  value={newProject.title}
                  onChange={e => setNewProject({ ...newProject, title: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600">Research Domain</label>
                <select
                  value={newProject.domain}
                  onChange={e => setNewProject({ ...newProject, domain: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering'].map(d => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600">Research Topic</label>
                <input
                  type="text"
                  placeholder="Specific research topic..."
                  value={newProject.topic}
                  onChange={e => setNewProject({ ...newProject, topic: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600">Project Abstract</label>
                <textarea
                  placeholder="Brief overview of research goals..."
                  value={newProject.abstract}
                  onChange={e => setNewProject({ ...newProject, abstract: e.target.value })}
                  rows={3}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                onClick={() => setShowCreate(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateProject}
                className="px-5 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition"
              >
                Create Project
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
