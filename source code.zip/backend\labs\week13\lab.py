import json
from typing import Dict, Any, List
from app.workflows.discipline_engine import DisciplineEngineeringEngine, DOMAIN_PROFILES

def run_lab_week13() -> Dict[str, Any]:
    engine = DisciplineEngineeringEngine()

    # Domain 1: Computer Science
    cs_adapt = engine.adapt_domain(
        domain="Computer Science",
        topic="Decentralized Multi-Agent Consensus in Cyber-Physical Grids",
        historical_budget_changes=[100000.0, 110000.0]
    )

    # Assignment 1: Second Domain Implementation (Electrical Engineering)
    ee_adapt = engine.adapt_domain(
        domain="Electrical Engineering",
        topic="High-Penetration Renewable Microgrid Inverters with Autonomous Black-Start",
        historical_budget_changes=[150000.0, 155000.0]
    )

    # Domain 3: Mechanical Engineering
    me_adapt = engine.adapt_domain(
        domain="Mechanical Engineering",
        topic="Bio-Inspired Robotic Swarms for Non-Destructive Structural Inspection",
        historical_budget_changes=[80000.0, 85000.0]
    )

    # Domain 4: Civil Engineering
    ce_adapt = engine.adapt_domain(
        domain="Civil Engineering",
        topic="Carbon-Negative Smart Concrete Embedded with Real-Time Micro-Strain Telemetry",
        historical_budget_changes=[90000.0, 92000.0]
    )

    # Assignment 2: Trend-Based Escalation on Monotonically Rising Budget Risk
    # Consecutive upward budget inflation: $100k -> $150k -> $220k (monotonically increasing 3 times)
    escalated_domain = engine.adapt_domain(
        domain="Computer Science",
        topic="Extreme High-Compute AI Cluster",
        historical_budget_changes=[100000.0, 150000.0, 220000.0]
    )

    return {
        "week": 13,
        "title": "Lab 13: Discipline-Specific Engineering Agents -- Multi-Domain Adaptation & Trend Escalation",
        "supported_engineering_disciplines": list(DOMAIN_PROFILES.keys()),
        "domain_1_computer_science": cs_adapt,
        "assignment_1_second_domain_electrical": {
            "domain": "Electrical Engineering",
            "adaptation": ee_adapt,
            "target_agencies": ee_adapt["profile"]["target_agencies"],
            "budget_emphasis": ee_adapt["budget_guidelines"],
            "compliance_rules": ee_adapt["compliance_requirements"],
            "cross_domain_synergy_verified": ee_adapt["domain"] != cs_adapt["domain"]
        },
        "domain_3_mechanical": me_adapt,
        "domain_4_civil": ce_adapt,
        "assignment_2_trend_escalation": {
            "historical_budget_trend": [100000.0, 150000.0, 220000.0],
            "trend_escalation_triggered": escalated_domain["trend_escalation_triggered"],
            "escalation_reason": escalated_domain["escalation_reason"],
            "escalation_passed": escalated_domain["trend_escalation_triggered"] is True
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week13()
    print(json.dumps(result, indent=2))
