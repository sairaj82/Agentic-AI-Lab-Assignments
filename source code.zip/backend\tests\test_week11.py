import pytest
from labs.week11.lab import run_lab_week11

def test_week11_execution():
    result = run_lab_week11()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 11

def test_week11_assignments():
    result = run_lab_week11()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 11 must contain at least 2 assignment outputs'
