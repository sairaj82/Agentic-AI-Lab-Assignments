import React, { useState, useEffect } from 'react';
import { GraduationCap, CheckCircle2, ChevronRight, Award, BookOpen, Clock } from 'lucide-react';
import { api } from '../services/api';

interface LabsPageProps {
  onOpenDetail: (week: number) => void;
}

export const LabsPage: React.FC<LabsPageProps> = ({ onOpenDetail }) => {
  const [labs, setLabs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getLabs()
      .then(data => {
        setLabs(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">14-Week Agentic AI Lab Progress</h2>
          <p className="text-slate-500 text-sm mt-1">
            Complete curriculum implementation: Week 1 to Week 14 with assignments, tests, and execution traces
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" /> 14/14 Labs Completed & Verified
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {labs.map((lab: any) => (
          <div
            key={lab.week_number}
            onClick={() => onOpenDetail(lab.week_number)}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-blue-300 transition cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100 uppercase tracking-wide">
                  Week {lab.week_number}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm group-hover:text-blue-600 transition line-clamp-2">
                {lab.lab_title}
              </h3>

              <p className="text-xs text-slate-500 mt-2 leading-relaxed line-clamp-2">
                {lab.objective}
              </p>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100">
              <div className="space-y-1 mb-3">
                {lab.assignments?.slice(0, 2).map((asg: string, i: number) => (
                  <p key={i} className="text-[11px] text-slate-600 truncate flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></span>
                    <span className="truncate">{asg}</span>
                  </p>
                ))}
              </div>

              <div className="flex items-center justify-between text-xs text-blue-600 font-semibold group-hover:translate-x-0.5 transition">
                <span>View Lab Details & Tests</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
