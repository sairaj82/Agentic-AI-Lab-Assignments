import datetime
from typing import Dict, Any, List, Optional

class MemoryRecord:
    def __init__(self, key: str, value: Any, source: str, topic_namespace: str = "default", ttl_days: int = 365):
        self.key = key
        self.value = value
        self.source = source
        self.topic_namespace = topic_namespace
        self.timestamp = datetime.datetime.now()
        self.ttl_days = ttl_days
        self.version = 1

    def is_stale(self, max_days_threshold: Optional[int] = None) -> bool:
        threshold = max_days_threshold if max_days_threshold is not None else self.ttl_days
        age_days = (datetime.datetime.now() - self.timestamp).total_seconds() / (24 * 3600)
        return age_days > threshold

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "value": self.value,
            "source": self.source,
            "topic_namespace": self.topic_namespace,
            "timestamp": self.timestamp.isoformat(),
            "ttl_days": self.ttl_days,
            "version": self.version,
            "is_stale": self.is_stale()
        }

class ProjectMemoryStore:
    def __init__(self):
        # Short-term session memory
        self.session_state: Dict[str, Any] = {}
        # Long-term persistent project records: namespace -> key -> MemoryRecord
        self.long_term_store: Dict[str, Dict[str, MemoryRecord]] = {}
        # Audit log of memory mutations
        self.mutation_log: List[Dict[str, Any]] = []

    # Session Memory
    def set_session(self, key: str, value: Any):
        self.session_state[key] = value

    def get_session(self, key: str, default: Any = None) -> Any:
        return self.session_state.get(key, default)

    # Scoped Long-Term Memory (Lab 4 Assignment 1: isolated namespaces)
    def record_fact(self, key: str, value: Any, source: str, topic_namespace: str = "default", ttl_days: int = 365, authorized: bool = True) -> Dict[str, Any]:
        if not authorized:
            raise PermissionError("Unauthorized attempt to mutate project memory without faculty approval.")

        if topic_namespace not in self.long_term_store:
            self.long_term_store[topic_namespace] = {}

        existing = self.long_term_store[topic_namespace].get(key)
        conflict_detected = False
        previous_val = None

        if existing:
            conflict_detected = (existing.value != value)
            previous_val = existing.value
            existing.value = value
            existing.source = source
            existing.timestamp = datetime.datetime.now()
            existing.version += 1
            record = existing
        else:
            record = MemoryRecord(key, value, source, topic_namespace, ttl_days)
            self.long_term_store[topic_namespace][key] = record

        log_entry = {
            "action": "UPDATE" if existing else "INSERT",
            "topic_namespace": topic_namespace,
            "key": key,
            "value": value,
            "source": source,
            "conflict_detected": conflict_detected,
            "previous_value": previous_val,
            "timestamp": datetime.datetime.now().isoformat()
        }
        self.mutation_log.append(log_entry)
        return {"status": "SUCCESS", "record": record.to_dict(), "conflict_logged": conflict_detected}

    # Scoped Retrieval with source tagging
    def retrieve(self, key: str, topic_namespace: str = "default") -> Optional[Dict[str, Any]]:
        ns_store = self.long_term_store.get(topic_namespace, {})
        rec = ns_store.get(key)
        return rec.to_dict() if rec else None

    def retrieve_all_for_topic(self, topic_namespace: str) -> List[Dict[str, Any]]:
        ns_store = self.long_term_store.get(topic_namespace, {})
        return [rec.to_dict() for rec in ns_store.values()]

    # Staleness Policy Check (Lab 4 Assignment 2)
    def prune_stale_records(self, max_days: int = 90, topic_namespace: Optional[str] = None) -> Dict[str, Any]:
        namespaces = [topic_namespace] if topic_namespace else list(self.long_term_store.keys())
        pruned_keys = []

        for ns in namespaces:
            if ns in self.long_term_store:
                keys_to_delete = []
                for k, rec in self.long_term_store[ns].items():
                    if rec.is_stale(max_days):
                        keys_to_delete.append(k)
                for k in keys_to_delete:
                    del self.long_term_store[ns][k]
                    pruned_keys.append(f"{ns}:{k}")

        return {
            "status": "SUCCESS",
            "max_age_days_checked": max_days,
            "pruned_count": len(pruned_keys),
            "pruned_records": pruned_keys
        }

project_memory = ProjectMemoryStore()
