import os
import json
import datetime
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

# Tool 1: Funding Search Tool
def tool_search_funding(keyword: str, domain: Optional[str] = None, max_amount: Optional[float] = None) -> Dict[str, Any]:
    """Search available grant database by topic, domain, or maximum budget."""
    from app.database.session import SessionLocal
    from app.database.models import GrantOpportunity

    db = SessionLocal()
    try:
        query = db.query(GrantOpportunity)
        if domain and domain.lower() != "all":
            query = query.filter(GrantOpportunity.domain.ilike(f"%{domain}%"))
        
        results = query.all()
        matched = []
        kw_lower = keyword.lower() if keyword else ""

        for opp in results:
            text_corpus = (opp.title + " " + opp.description + " " + opp.eligibility).lower()
            relevance = 50.0
            if kw_lower and kw_lower in text_corpus:
                relevance += 40.0
            if domain and domain.lower() in opp.domain.lower():
                relevance += 10.0
            if max_amount and opp.amount > max_amount:
                continue

            matched.append({
                "id": opp.id,
                "title": opp.title,
                "agency": opp.agency,
                "amount": opp.amount,
                "deadline": opp.deadline,
                "domain": opp.domain,
                "eligibility": opp.eligibility,
                "relevance_score": min(100.0, relevance)
            })

        matched.sort(key=lambda x: x["relevance_score"], reverse=True)
        return {"status": "SUCCESS", "matches_found": len(matched), "opportunities": matched[:5]}
    finally:
        db.close()

# Tool 2: Document Reader Tool
def tool_read_document(file_path: str, max_pages: int = 5) -> Dict[str, Any]:
    """Extract and read text from uploaded PDF or text file with error handling."""
    if not os.path.exists(file_path):
        return {"status": "ERROR", "error": f"File does not exist: {file_path}", "text": ""}
    
    extracted = ""
    try:
        if file_path.lower().endswith(".pdf"):
            import pypdf
            reader = pypdf.PdfReader(file_path)
            num_pages = len(reader.pages)
            pages_to_read = min(num_pages, max_pages)
            for idx in range(pages_to_read):
                page_text = reader.pages[idx].extract_text()
                if page_text:
                    extracted += page_text + "\n"
            return {"status": "SUCCESS", "pages_read": pages_to_read, "total_pages": num_pages, "text": extracted}
        else:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                extracted = f.read()
            return {"status": "SUCCESS", "pages_read": 1, "total_pages": 1, "text": extracted}
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "text": ""}

# Tool 3: Budget Calculator Tool
def tool_calculate_budget(items: List[Dict[str, Any]], max_limit: float = 1000000.0) -> Dict[str, Any]:
    """Calculate sub-totals by category, institutional indirect cost (26%), and check budget ceiling."""
    subtotals = {
        "Personnel": 0.0,
        "Equipment": 0.0,
        "Travel": 0.0,
        "Consumables": 0.0,
        "Indirect": 0.0,
        "Miscellaneous": 0.0
    }

    direct_costs = 0.0
    for item in items:
        cat = item.get("category", "Miscellaneous")
        qty = float(item.get("quantity", 1))
        cost = float(item.get("unit_cost", 0.0))
        line_total = qty * cost
        subtotals[cat] = subtotals.get(cat, 0.0) + line_total
        if cat != "Indirect":
            direct_costs += line_total

    # Calculate standard indirect if not provided
    if subtotals.get("Indirect", 0.0) == 0.0:
        calculated_indirect = direct_costs * 0.26
        subtotals["Indirect"] = round(calculated_indirect, 2)

    total_project_cost = sum(subtotals.values())
    within_limit = total_project_cost <= max_limit
    overflow = max(0.0, total_project_cost - max_limit)

    return {
        "status": "SUCCESS",
        "category_subtotals": {k: round(v, 2) for k, v in subtotals.items()},
        "direct_costs": round(direct_costs, 2),
        "total_cost": round(total_project_cost, 2),
        "budget_limit": max_limit,
        "within_limit": within_limit,
        "budget_overflow": round(overflow, 2)
    }

# Tool 4: Deadline Checker Tool
def tool_check_deadline(deadline_str: str) -> Dict[str, Any]:
    """Check remaining days until deadline and assess urgency/feasibility."""
    try:
        now = datetime.datetime.now()
        target = datetime.datetime.strptime(deadline_str, "%Y-%m-%d")
        delta = (target - now).days

        if delta < 0:
            urgency = "EXPIRED"
            feasible = False
        elif delta <= 14:
            urgency = "CRITICAL_SHORT"
            feasible = True
        elif delta <= 45:
            urgency = "ACTIVE_WINDOW"
            feasible = True
        else:
            urgency = "COMFORTABLE"
            feasible = True

        return {
            "status": "SUCCESS",
            "deadline": deadline_str,
            "days_remaining": delta,
            "urgency": urgency,
            "submission_feasible": feasible
        }
    except Exception as e:
        return {"status": "ERROR", "error": f"Invalid date format: {deadline_str}. Expected YYYY-MM-DD", "days_remaining": -1}

# Tool 5: Notification Drafting Tool (Lab 2 Assignment 1)
def tool_draft_notification(faculty_name: str, opportunity_title: str, deadline: str, days_left: int, action_required: str) -> Dict[str, Any]:
    """Draft an official institutional email notice to PI alerting them of grant milestones and requirements."""
    subject = f"[URGENT GRANT MILESTONE] {opportunity_title} - Due in {days_left} Days"
    body = (
        f"Dear {faculty_name},\n\n"
        f"This automated grant tracking alert concerns your prospective proposal for '{opportunity_title}'.\n"
        f"Official submission deadline: {deadline} ({days_left} calendar days remaining).\n\n"
        f"Action Required:\n{action_required}\n\n"
        f"Please ensure all compliance materials and internal authorizations are finalized 5 days prior to submission.\n\n"
        f"Best regards,\nOffice of Sponsored Research & Autonomous Grant Management System"
    )
    return {
        "status": "SUCCESS",
        "notification_type": "EMAIL_ALERT",
        "recipient": faculty_name,
        "subject": subject,
        "body": body,
        "timestamp": datetime.datetime.now().isoformat()
    }

# Tool 6: Multi-Tool Chain Executor (Lab 2 Assignment 2)
def execute_multi_tool_chain(topic: str, domain: str, items: List[Dict[str, Any]], faculty_name: str) -> Dict[str, Any]:
    """Chain 1: Search Opportunities -> 2: Check Deadline -> 3: Calculate Budget -> 4: Draft Notification."""
    execution_trace = []

    # Step 1: Search
    search_res = tool_search_funding(topic, domain)
    execution_trace.append({"step": 1, "tool": "tool_search_funding", "result": search_res})

    best_opp = search_res["opportunities"][0] if search_res.get("opportunities") else None
    if not best_opp:
        return {"status": "FAILED", "trace": execution_trace, "final_summary": "No matching grants found."}

    # Step 2: Deadline
    dl_res = tool_check_deadline(best_opp["deadline"])
    execution_trace.append({"step": 2, "tool": "tool_check_deadline", "result": dl_res})

    # Step 3: Budget
    budget_res = tool_calculate_budget(items, max_limit=best_opp["amount"])
    execution_trace.append({"step": 3, "tool": "tool_calculate_budget", "result": budget_res})

    # Step 4: Notification
    action_note = "Verify indirect rate cap and finalize itemized sub-awards." if budget_res["within_limit"] else f"WARNING: Budget exceeds cap by ${budget_res['budget_overflow']:,.2f}. Reduce equipment or personnel lines."
    notif_res = tool_draft_notification(
        faculty_name=faculty_name,
        opportunity_title=best_opp["title"],
        deadline=best_opp["deadline"],
        days_left=dl_res.get("days_remaining", 0),
        action_required=action_note
    )
    execution_trace.append({"step": 4, "tool": "tool_draft_notification", "result": notif_res})

    return {
        "status": "SUCCESS",
        "selected_opportunity": best_opp,
        "deadline_status": dl_res,
        "budget_status": budget_res,
        "notification": notif_res,
        "trace": execution_trace
    }

# Tool Registry for dynamic lookup
AVAILABLE_TOOLS = {
    "search_funding": tool_search_funding,
    "read_document": tool_read_document,
    "calculate_budget": tool_calculate_budget,
    "check_deadline": tool_check_deadline,
    "draft_notification": tool_draft_notification,
    "multi_tool_chain": execute_multi_tool_chain
}
