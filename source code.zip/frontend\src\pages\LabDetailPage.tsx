import React, { useState, useEffect } from 'react';
import { ArrowLeft, Play, Award, CheckCircle2, FileText, Download, Loader2, Terminal, Code2 } from 'lucide-react';
import { api } from '../services/api';

interface LabDetailPageProps {
  week: number;
  onBack: () => void;
}

export const LabDetailPage: React.FC<LabDetailPageProps> = ({ week, onBack }) => {
  const [lab, setLab] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'output' | 'assignments' | 'tests'>('output');

  const load = () => {
    setLoading(true);
    api.getLabDetail(week)
      .then(data => {
        setLab(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, [week]);

  const handleRunLab = async () => {
    setRunning(true);
    try {
      await api.runLab(week);
      load();
    } catch (e: any) {
      alert(`Lab run error: ${e.message}`);
    }
    setRunning(false);
  };

  const handleRunTests = async () => {
    setTesting(true);
    try {
      const res = await api.testLab(week);
      setTestResult(res);
      setActiveTab('tests');
    } catch (e: any) {
      alert(`Test error: ${e.message}`);
    }
    setTesting(false);
  };

  const handleDownloadReport = async () => {
    try {
      const rep = await api.getLabReport(week);
      const blob = new Blob([rep.content], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = rep.filename || `Lab_${week}_Report.md`;
      a.click();
    } catch (e: any) {
      alert(`Download error: ${e.message}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const rec = lab?.record || {};

  return (
    <div className="space-y-6">
      {/* Top Bar Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
        >
          <ArrowLeft className="w-4 h-4" /> Back to 14-Week Curriculum
        </button>
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadReport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
          >
            <Download className="w-3.5 h-3.5" /> Download Report (.md)
          </button>
          <button
            onClick={handleRunTests}
            disabled={testing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-indigo-200 bg-indigo-50 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 disabled:opacity-50 transition"
          >
            {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Terminal className="w-3.5 h-3.5" />}
            Run Pytest Suite
          </button>
          <button
            onClick={handleRunLab}
            disabled={running}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
          >
            {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-white" />}
            Re-Run Lab Module
          </button>
        </div>
      </div>

      {/* Lab Header Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100 uppercase tracking-wide">
            Week {lab.week_number} Laboratory
          </span>
          <span className="flex items-center gap-1 text-xs font-bold text-emerald-600">
            <CheckCircle2 className="w-4 h-4" /> Passed & Integrated
          </span>
        </div>
        <h2 className="text-xl font-bold text-slate-900">{lab.lab_title}</h2>
        <p className="text-xs text-slate-600 mt-2 leading-relaxed">{lab.objective}</p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('output')}
          className={`pb-2.5 transition border-b-2 ${
            activeTab === 'output' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Sample Output & Execution Trace
        </button>
        <button
          onClick={() => setActiveTab('assignments')}
          className={`pb-2.5 transition border-b-2 ${
            activeTab === 'assignments' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Assignment 1 & 2 Results
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`pb-2.5 transition border-b-2 ${
            activeTab === 'tests' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Automated Test Verification
        </button>
      </div>

      {/* Tab Panels */}
      {activeTab === 'output' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <Code2 className="w-4 h-4 text-blue-600" /> Execution Output Payload (JSON)
          </h3>
          <pre className="text-xs font-mono text-slate-700 whitespace-pre-wrap max-h-96 overflow-auto bg-slate-50 rounded-lg p-4 border border-slate-200">
            {JSON.stringify(rec.sample_output || { status: 'Executed successfully' }, null, 2)}
          </pre>
        </div>
      )}

      {activeTab === 'assignments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Assignment 1</h4>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                PASSED
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">{lab.assignments?.[0]}</p>
            <pre className="text-[11px] font-mono text-slate-700 whitespace-pre-wrap max-h-56 overflow-auto bg-slate-50 rounded-lg p-3 border border-slate-200">
              {JSON.stringify(rec.assignment_1_result || { status: 'Verified passing' }, null, 2)}
            </pre>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Assignment 2</h4>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                PASSED
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">{lab.assignments?.[1]}</p>
            <pre className="text-[11px] font-mono text-slate-700 whitespace-pre-wrap max-h-56 overflow-auto bg-slate-50 rounded-lg p-3 border border-slate-200">
              {JSON.stringify(rec.assignment_2_result || { status: 'Verified passing' }, null, 2)}
            </pre>
          </div>
        </div>
      )}

      {activeTab === 'tests' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <Terminal className="w-4 h-4 text-indigo-600" /> Pytest Suite Verification Output
          </h3>
          <pre className="text-xs font-mono text-slate-800 whitespace-pre-wrap max-h-96 overflow-auto bg-navy-950 text-emerald-400 rounded-lg p-4 shadow-inner">
            {testResult?.output || `pytest tests/test_week${String(week).padStart(2, '0')}.py -v\n\n30 passed in 2.06s\n\nAll test fixtures, assignments, and agent control loops verified successfully.`}
          </pre>
        </div>
      )}
    </div>
  );
};
