import pytest
from labs.week01.lab import run_lab_week01

def test_week01_execution():
    result = run_lab_week01()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 1

def test_week01_assignments():
    result = run_lab_week01()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 1 must contain at least 2 assignment outputs'
