import json
import time
import datetime
from typing import Dict, Any, List

# Import all core subsystem components
from app.agents.funding_discovery.agent import funding_agent
from app.agents.literature_review.agent import literature_agent
from app.agents.proposal_drafting.agent import proposal_agent
from app.agents.budget_planning.agent import budget_agent
from app.agents.compliance_checking.agent import compliance_agent
from app.agents.submission.agent import submission_agent
from app.runtime.agent_runtime import runtime
from app.skills.grant_skills import SKILL_REGISTRY, GrantSkill
from app.memory.project_memory import project_memory
from app.governance.governance_engine import governance_engine
from app.connectors.mcp_connector import mcp_server
from app.workflows.node_graph import grant_node_graph
from app.workflows.parallel_swarm import grant_swarm

# Lab 14 Assignment 1: Second Reusable Capstone Skill
class InterdisciplinaryGrantSynthesisSkill(GrantSkill):
    def __init__(self):
        super().__init__(
            name="interdisciplinary_synthesis",
            description="Synthesizes cross-disciplinary research frameworks combining CS, Electrical, and Mechanical domains.",
            instructions="Identify mutual engineering synergies, co-design methodologies, and joint funding opportunities.",
            constraints=["Must clearly allocate technical ownership per engineering department."]
        )

    def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        primary_domain = payload.get("primary_domain", "Computer Science")
        secondary_domain = payload.get("secondary_domain", "Electrical Engineering")
        topic = payload.get("topic", "Autonomous Resilient Microgrids")

        return {
            "skill": self.name,
            "status": "SUCCESS",
            "interdisciplinary_title": f"Cyber-Physical Co-Design: Integrating {primary_domain} and {secondary_domain} for {topic}",
            "synergy_matrix": {
                f"{primary_domain} Contribution": "Verifiable multi-agent consensus algorithms and formal safety proofs.",
                f"{secondary_domain} Contribution": "High-speed power inverter hardware-in-the-loop (PHIL) testbed validation."
            },
            "joint_target_program": "NSF/DOE Joint Initiative on Resilient Clean Energy Computing",
            "co_pi_structure": "PI: Dr. Aris Thorne (CS), Co-PI: Dr. Elena Rostova (ECE)"
        }

def run_lab_week14() -> Dict[str, Any]:
    start_time = time.time()
    lifecycle_log = []

    # Step 1: Faculty Input & Memory Initialization
    faculty_user = "Dr. Aris Thorne"
    topic = "Decentralized Cyber-Physical Multi-Agent Verification"
    domain = "Computer Science"
    project_memory.set_session("current_faculty", faculty_user)
    project_memory.record_fact("capstone_project_topic", topic, "Faculty Workspace Intake", topic_namespace="capstone_2026")

    lifecycle_log.append({
        "step": 1,
        "phase": "Faculty Project Intake & Scoped Memory",
        "actor": faculty_user,
        "output": {"topic": topic, "domain": domain, "namespace": "capstone_2026"}
    })

    # Step 2: Agent 1 - Funding Discovery
    discovery_res = funding_agent.execute(topic=topic, domain=domain, max_budget=1000000.0)
    lifecycle_log.append({
        "step": 2,
        "phase": "Funding Opportunity Discovery & Ranking",
        "actor": funding_agent.name,
        "output": {"top_match": discovery_res["top_match"], "total_ranked": discovery_res["matched_count"]}
    })

    # Step 3: Agent 2 - Literature Review (RAG synthesis & research gaps)
    lit_res = literature_agent.execute(topic=topic)
    lifecycle_log.append({
        "step": 3,
        "phase": "Deep Literature Review & Research Gap Identification",
        "actor": literature_agent.name,
        "output": {"citations": lit_res["evidence_sources"], "identified_gaps": lit_res["identified_gaps"]}
    })

    # Step 4: Agent 3 - Proposal Drafting
    proposal_res = proposal_agent.execute(
        topic=topic,
        domain=domain,
        pi_name=faculty_user,
        gaps=lit_res["identified_gaps"]
    )
    lifecycle_log.append({
        "step": 4,
        "phase": "Structured Proposal Drafting",
        "actor": proposal_agent.name,
        "output": {"title": proposal_res["title"], "objectives_count": len(proposal_res["objectives"])}
    })

    # Step 5: Agent 4 - Budget Planning & Justification
    budget_res = budget_agent.execute(
        project_id=1,
        target_opportunity_amount=discovery_res["top_match"]["amount"] if discovery_res.get("top_match") else 750000.0
    )
    lifecycle_log.append({
        "step": 5,
        "phase": "Itemized Budget Formulation & Indirect Overhead",
        "actor": budget_agent.name,
        "output": {
            "total_budget": budget_res["budget_calculation"]["total_cost"],
            "within_limit": budget_res["within_limit"]
        }
    })

    # Step 6: Agent 5 - Compliance Checking
    compliance_res = compliance_agent.execute(
        project_id=1,
        proposal_data={"topic": topic, "objectives": proposal_res["objectives"]},
        budget_data=budget_res
    )
    lifecycle_log.append({
        "step": 6,
        "phase": "Federal Solicitation & Institutional Compliance Audit",
        "actor": compliance_agent.name,
        "output": {
            "compliance_score": compliance_res["overall_score"],
            "eligibility_status": compliance_res["eligibility_status"],
            "warnings_count": len(compliance_res["warnings"])
        }
    })

    # Step 7: Agent 6 - Submission Package Assembly
    package = submission_agent.assemble_package(
        project_id=1,
        proposal_data={"title": proposal_res["title"], "pi_name": faculty_user, "full_draft": proposal_res["full_draft"]},
        budget_data=budget_res,
        compliance_data=compliance_res
    )
    lifecycle_log.append({
        "step": 7,
        "phase": "Submission Package Assembly & Pre-Submission Audit",
        "actor": submission_agent.name,
        "output": {"checklist_items": len(package["checklist"]), "ready_for_faculty_approval": package["ready_for_faculty_approval"]}
    })

    # Step 8: Human Approval Gate & Submission Dispatch
    # Test submission dispatch with verified faculty authorization
    submission_res = submission_agent.execute_submission(
        project_id=1,
        package=package,
        faculty_approved=True,
        approver_name=faculty_user
    )
    lifecycle_log.append({
        "step": 8,
        "phase": "Human Sign-Off & Official Agency Dispatch",
        "actor": submission_agent.name,
        "output": {
            "tracking_number": submission_res["tracking_number"],
            "status": submission_res["status"],
            "approved_by": submission_res["approved_by"]
        }
    })

    # Lab 14 Assignment 1: Execute Second Reusable Skill (Interdisciplinary Synthesis)
    inter_skill = InterdisciplinaryGrantSynthesisSkill()
    inter_res = inter_skill.execute({
        "primary_domain": "Computer Science",
        "secondary_domain": "Electrical Engineering",
        "topic": topic
    })

    # Lab 14 Assignment 2: Expanded Evaluation Regression Suite
    eval_suite = governance_engine.run_quantitative_evaluation()

    total_time = round(time.time() - start_time, 3)

    return {
        "week": 14,
        "title": "Lab 14: Final Capstone Project Studio -- Integrated Autonomous Grant Management System",
        "complete_lifecycle_log": lifecycle_log,
        "six_agents_executed": [
            funding_agent.name,
            literature_agent.name,
            proposal_agent.name,
            budget_agent.name,
            compliance_agent.name,
            submission_agent.name
        ],
        "final_artifacts": {
            "proposal_title": proposal_res["title"],
            "selected_opportunity": discovery_res["top_match"]["title"] if discovery_res.get("top_match") else "N/A",
            "requested_funding": budget_res["budget_calculation"]["total_cost"],
            "compliance_score": compliance_res["overall_score"],
            "tracking_number": submission_res["tracking_number"],
            "submission_status": submission_res["status"]
        },
        "assignment_1_interdisciplinary_skill": inter_res,
        "assignment_2_expanded_evaluation_suite": eval_suite,
        "total_capstone_execution_time_sec": total_time,
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week14()
    print(json.dumps(result, indent=2))
