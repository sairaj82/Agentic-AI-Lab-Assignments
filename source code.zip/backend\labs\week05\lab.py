import json
import os
from typing import Dict, Any, List
from app.connectors.mcp_connector import mcp_server, MCPCapabilityManifest

def run_lab_week05() -> Dict[str, Any]:
    # 1. Capability Discovery
    manifest = MCPCapabilityManifest.get_manifest()

    # 2. Test Safe read_file capability (Valid file)
    safe_file_res = mcp_server.dispatch("read_file", {"path": "requirements.txt"})

    # 3. Test Assignment 2: Safe-Directory Restriction / Path Traversal Attack Defense
    traversal_res = mcp_server.dispatch("read_file", {"path": "../../windows/system32/cmd.exe"})

    # 4. Test query_database (Valid SELECT)
    valid_sql_res = mcp_server.dispatch("query_database", {"sql_query": "SELECT id, title, amount, agency FROM grant_opportunities LIMIT 3;"})

    # 5. Test query_database Security Check (Prohibited DROP/INSERT mutation)
    prohibited_sql_res = mcp_server.dispatch("query_database", {"sql_query": "DROP TABLE grant_opportunities;"})

    # 6. Test Assignment 1: Discoverable Capability (export_grant_manifest)
    manifest_export_res = mcp_server.dispatch("export_grant_manifest", {"project_id": 1})

    # 7. Test search_funding capability
    search_res = mcp_server.dispatch("search_funding", {"keyword": "CPS", "domain": "Computer Science"})

    return {
        "week": 5,
        "title": "Lab 5: MCP-Style Connector -- Mini Integration Layer & Permission Boundaries",
        "discovered_manifest": manifest,
        "sample_executions": {
            "safe_read_file": {
                "success": safe_file_res.get("success"),
                "bytes_read": safe_file_res.get("bytes", 0)
            },
            "valid_database_query": {
                "success": valid_sql_res.get("success"),
                "rows_returned": valid_sql_res.get("rows_returned", 0),
                "sample_data": valid_sql_res.get("data", [])
            },
            "funding_search": {
                "matches_found": search_res.get("matches_found", 0)
            }
        },
        "assignment_1_new_capability": {
            "capability_name": "export_grant_manifest",
            "result": manifest_export_res,
            "passed": manifest_export_res.get("success") is True
        },
        "assignment_2_safe_directory_restriction": {
            "path_tested": "../../windows/system32/cmd.exe",
            "blocked": not traversal_res.get("success"),
            "security_error": traversal_res.get("error"),
            "passed": "denied" in traversal_res.get("error", "").lower() or "violation" in traversal_res.get("error", "").lower()
        },
        "sql_injection_defense": {
            "query_tested": "DROP TABLE grant_opportunities;",
            "blocked": not prohibited_sql_res.get("success"),
            "security_error": prohibited_sql_res.get("error"),
            "passed": "prohibited" in prohibited_sql_res.get("error", "").lower()
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week05()
    print(json.dumps(result, indent=2))
