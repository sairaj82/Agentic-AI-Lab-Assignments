import React, { useEffect, useState } from 'react';
import { Search, Plus, Pencil, Trash2, Star, X, Loader2, DollarSign, Calendar, Filter } from 'lucide-react';
import { api } from '../services/api';

const DOMAINS = ['All', 'Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering', 'Biomedical', 'Environmental'];
const EMPTY_OPP = {
  title: '',
  description: '',
  domain: 'Computer Science',
  funding_amount: 150000,
  deadline: '2025-12-31',
  eligibility_criteria: 'Accredited university faculty or research scientist',
  agency: 'National Science Foundation'
};

export const OpportunitiesPage: React.FC = () => {
  const [opps, setOpps] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [keyword, setKeyword] = useState('');
  const [domainFilter, setDomainFilter] = useState('All');
  const [showModal, setShowModal] = useState(false);
  const [editingOpp, setEditingOpp] = useState<any>(null);
  const [form, setForm] = useState({ ...EMPTY_OPP });
  const [ranked, setRanked] = useState<any>(null);
  const [ranking, setRanking] = useState(false);

  const load = () => {
    setLoading(true);
    api.getOpportunities(domainFilter, keyword)
      .then(data => {
        setOpps(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, [domainFilter]);

  const handleSearch = () => load();

  const openCreate = () => {
    setEditingOpp(null);
    setForm({ ...EMPTY_OPP });
    setShowModal(true);
  };

  const openEdit = (o: any) => {
    setEditingOpp(o);
    setForm({
      title: o.title,
      description: o.description || '',
      domain: o.domain,
      funding_amount: o.funding_amount,
      deadline: o.deadline,
      eligibility_criteria: o.eligibility_criteria || '',
      agency: o.agency || ''
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (editingOpp) {
      await api.updateOpportunity(editingOpp.id, form);
    } else {
      await api.createOpportunity(form);
    }
    setShowModal(false);
    load();
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this funding opportunity?')) {
      await api.deleteOpportunity(id);
      load();
    }
  };

  const handleRank = async () => {
    setRanking(true);
    try {
      const r = await api.rankOpportunities(
        keyword || 'Multi-Agent Systems for Cyber-Physical Verification',
        domainFilter === 'All' ? 'Computer Science' : domainFilter
      );
      setRanked(r);
    } catch {}
    setRanking(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Grant Opportunities</h2>
          <p className="text-slate-500 text-sm mt-1">Discover, manage, and rank funding opportunities matching research domains</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition shadow-sm"
        >
          <Plus className="w-4 h-4" /> Add Opportunity
        </button>
      </div>

      {/* Filters & Actions */}
      <div className="flex flex-wrap gap-3">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by grant title or keyword..."
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
          />
        </div>
        <select
          value={domainFilter}
          onChange={e => setDomainFilter(e.target.value)}
          className="px-4 py-2.5 rounded-lg border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
        >
          {DOMAINS.map(d => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <button
          onClick={handleSearch}
          className="px-4 py-2.5 rounded-lg border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition"
        >
          <Filter className="w-4 h-4 text-slate-500" /> Filter
        </button>
        <button
          onClick={handleRank}
          disabled={ranking}
          className="px-4 py-2.5 rounded-lg bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2 transition shadow-sm"
        >
          {ranking ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-4 h-4" />} Rank by Relevance
        </button>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-xs text-slate-500 uppercase tracking-wider border-b border-slate-200">
                <th className="px-5 py-3">Title & Agency</th>
                <th className="px-5 py-3">Domain</th>
                <th className="px-5 py-3">Funding Amount</th>
                <th className="px-5 py-3">Deadline</th>
                <th className="px-5 py-3">Eligibility</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {opps.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-400 italic">
                    No opportunities found. Click "Add Opportunity" or broaden your search criteria.
                  </td>
                </tr>
              ) : (
                opps.map((o: any) => (
                  <tr key={o.id} className="border-b border-slate-100 hover:bg-blue-50/30 transition">
                    <td className="px-5 py-3.5 max-w-[280px]">
                      <div className="font-semibold text-slate-900 truncate">{o.title}</div>
                      <div className="text-xs text-slate-400 truncate">{o.agency || 'Federal Agency'}</div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-100">
                        {o.domain}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 font-medium text-slate-800">
                      <span className="flex items-center gap-1 font-mono">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                        {(o.funding_amount || 0).toLocaleString()}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      <span className="flex items-center gap-1 text-xs">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {o.deadline || 'Rolling'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-xs text-slate-500 max-w-[200px] truncate">
                      {o.eligibility_criteria || 'General Eligibility'}
                    </td>
                    <td className="px-5 py-3.5 text-right space-x-2">
                      <button
                        onClick={() => openEdit(o)}
                        className="p-1 text-slate-400 hover:text-blue-600 transition"
                        title="Edit Opportunity"
                      >
                        <Pencil className="w-4 h-4 inline" />
                      </button>
                      <button
                        onClick={() => handleDelete(o.id)}
                        className="p-1 text-slate-400 hover:text-red-600 transition"
                        title="Delete Opportunity"
                      >
                        <Trash2 className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* AI Ranking result */}
      {ranked && (
        <div className="bg-white rounded-xl border border-indigo-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-indigo-900 flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" /> AI Funding Discovery Agent Evaluation & Ranking
            </h3>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100">
              Ranked by Domain Match & Relevance
            </span>
          </div>
          <pre className="text-xs font-mono text-slate-700 whitespace-pre-wrap max-h-72 overflow-auto bg-slate-50 rounded-lg p-4 border border-slate-200">
            {JSON.stringify(ranked, null, 2)}
          </pre>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-900">{editingOpp ? 'Edit Opportunity' : 'New Grant Opportunity'}</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-600">Grant Title</label>
                <input
                  type="text"
                  placeholder="e.g. NSF Cyber-Physical Resilient Networks"
                  value={form.title}
                  onChange={e => setForm({ ...form, title: e.target.value })}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600">Description</label>
                <textarea
                  placeholder="Program overview and priority topics..."
                  value={form.description}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                  rows={3}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600">Discipline Domain</label>
                  <select
                    value={form.domain}
                    onChange={e => setForm({ ...form, domain: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {DOMAINS.filter(d => d !== 'All').map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600">Funding Agency</label>
                  <input
                    type="text"
                    placeholder="e.g. NSF, DARPA, DOE"
                    value={form.agency}
                    onChange={e => setForm({ ...form, agency: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600">Funding Amount ($)</label>
                  <input
                    type="number"
                    value={form.funding_amount}
                    onChange={e => setForm({ ...form, funding_amount: Number(e.target.value) })}
                    className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600">Deadline</label>
                  <input
                    type="date"
                    value={form.deadline}
                    onChange={e => setForm({ ...form, deadline: e.target.value })}
                    className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600">Eligibility Criteria</label>
                <textarea
                  placeholder="Eligibility guidelines..."
                  value={form.eligibility_criteria}
                  onChange={e => setForm({ ...form, eligibility_criteria: e.target.value })}
                  rows={2}
                  className="w-full mt-1 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-5 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition"
              >
                {editingOpp ? 'Update Opportunity' : 'Create Opportunity'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
