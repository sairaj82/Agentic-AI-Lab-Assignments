import time
import datetime
from typing import Dict, Any, List, Optional

class GraphNode:
    def __init__(self, node_id: str, name: str, owner: str, success_criteria: str, failure_behavior: str):
        self.node_id = node_id
        self.name = name
        self.owner = owner
        self.success_criteria = success_criteria
        self.failure_behavior = failure_behavior
        self.retry_count = 0
        self.max_retries = 2

class GrantNodeGraph:
    def __init__(self):
        self.nodes = [
            GraphNode("intake", "Faculty Intake", "Faculty PI", "Valid topic and domain provided", "Request missing fields"),
            GraphNode("funding", "Funding Discovery", "Funding Discovery Agent", "Relevant grants found", "Broaden search keywords"),
            GraphNode("literature", "Literature Review", "Literature Review Agent", "Unresolved gaps identified", "Expand citation query"),
            GraphNode("proposal", "Proposal Drafting", "Proposal Drafting Agent", "Structured draft generated", "Regenerate sections"),
            GraphNode("budget", "Budget Planning", "Budget Planning Agent", "Total <= Opportunity cap", "Recalculate allocations"),
            GraphNode("compliance", "Compliance Check", "Compliance Agent", "Score >= 85", "Flag remediation items"),
            # Lab 7 Assignment 1: Security/Compliance Scan Node
            GraphNode("security_scan", "Institutional Security & ITAR Scan", "Security Specialist Agent", "Zero export control or dual-use violations", "Escalate to campus compliance"),
            GraphNode("human_approval", "Faculty PI Review & Approval", "Faculty PI", "Explicit human sign-off", "Halt submission"),
            GraphNode("submission", "Submission Dispatch", "Submission Agent", "Grant package bundle sealed", "Re-verify payload")
        ]

    def execute_graph(self, topic: str, domain: str, requested_budget: float = 157500.0, faculty_approved: bool = True) -> Dict[str, Any]:
        trace = []
        state: Dict[str, Any] = {
            "topic": topic,
            "domain": domain,
            "requested_budget": requested_budget,
            "faculty_approved": faculty_approved
        }

        for node in self.nodes:
            start_t = time.time()
            node_status = "SUCCESS"
            node_output = {}
            error_note = None

            if node.node_id == "intake":
                if not topic.strip():
                    node_status = "FAILED"
                    error_note = "Empty research topic provided."
                else:
                    node_output = {"topic": topic, "domain": domain, "verified": True}

            elif node.node_id == "funding":
                node_output = {
                    "matched_solicitation": "NSF Cyber-Physical Systems (CPS) Frontier Program",
                    "max_funding": 750000.0,
                    "deadline": "2026-11-15"
                }

            elif node.node_id == "literature":
                node_output = {
                    "citations_reviewed": 18,
                    "primary_gap": "Formal safety verification under asynchronous delays in multi-agent swarms"
                }

            elif node.node_id == "proposal":
                node_output = {
                    "sections_completed": ["Abstract", "Objectives", "Methodology", "Broader Impacts"],
                    "word_count": 3450
                }

            elif node.node_id == "budget":
                within_cap = requested_budget <= 750000.0
                if not within_cap:
                    node_status = "RETRY"
                    node.retry_count += 1
                    # Lab 7 Assignment 2: Retry Limit and Human Escalation
                    if node.retry_count > node.max_retries:
                        node_status = "ESCALATED_TO_HUMAN"
                        error_note = f"Exceeded retry limit ({node.max_retries}). Budget exceeds opportunity ceiling."
                    else:
                        error_note = "Budget exceeded ceiling. Re-scaling budget."
                else:
                    node_output = {"total_budget": requested_budget, "indirect_costs": requested_budget * 0.26}

            elif node.node_id == "compliance":
                node_output = {"compliance_score": 94.0, "eligibility": "VERIFIED"}

            elif node.node_id == "security_scan":
                # Lab 7 Assignment 1: Security Scan execution
                is_secure = "military" not in topic.lower() and "weapon" not in topic.lower()
                if is_secure:
                    node_output = {"itar_status": "CLEARED", "export_control": "EXEMPT", "data_sovereignty": "PASSED"}
                else:
                    node_status = "BLOCKED"
                    error_note = "Security scan detected dual-use keywords. Requires export control clearance."

            elif node.node_id == "human_approval":
                if faculty_approved:
                    node_output = {"decision": "APPROVED", "approver": "Principal Investigator", "signed_at": datetime.datetime.now().isoformat()}
                else:
                    node_status = "WAITING_APPROVAL"
                    error_note = "Submission paused at human approval gate. Requires explicit faculty sign-off."

            elif node.node_id == "submission":
                if not faculty_approved:
                    node_status = "BLOCKED"
                    error_note = "Cannot dispatch submission package without explicit human approval."
                else:
                    node_output = {
                        "submission_id": "NSF-FASTLANE-2026-8841",
                        "status": "DISPATCHED_TO_AGENCY",
                        "timestamp": datetime.datetime.now().isoformat()
                    }

            elapsed = round(time.time() - start_t, 3)
            trace_entry = {
                "node_id": node.node_id,
                "node_name": node.name,
                "owner": node.owner,
                "status": node_status,
                "output": node_output,
                "error": error_note,
                "elapsed_sec": elapsed
            }
            trace.append(trace_entry)

            # Conditional routing: break pipeline on failure or blockage
            if node_status in ["FAILED", "BLOCKED", "ESCALATED_TO_HUMAN", "WAITING_APPROVAL"]:
                break

        final_status = trace[-1]["status"] if trace else "UNKNOWN"
        return {
            "graph_status": final_status,
            "total_nodes_executed": len(trace),
            "trace": trace
        }

grant_node_graph = GrantNodeGraph()
