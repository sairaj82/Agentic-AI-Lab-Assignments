import json
from typing import Dict, Any, List
from app.workflows.node_graph import GrantNodeGraph

def run_lab_week07() -> Dict[str, Any]:
    # 1. Successful Graph Execution with Human Approval
    graph_engine = GrantNodeGraph()
    success_run = graph_engine.execute_graph(
        topic="Decentralized Cyber-Physical Swarm Verification",
        domain="Computer Science",
        requested_budget=157500.0,
        faculty_approved=True
    )

    # 2. Assignment 1: Security Scan Node in Action
    # Test A: Benign academic proposal (cleared)
    sec_cleared_trace = [t for t in success_run["trace"] if t["node_id"] == "security_scan"][0]

    # Test B: Dual-use restricted topic (blocked at security node)
    blocked_graph_engine = GrantNodeGraph()
    blocked_security_run = blocked_graph_engine.execute_graph(
        topic="Autonomous military weapon drone swarm targeting systems",
        domain="Mechanical Engineering",
        requested_budget=200000.0,
        faculty_approved=True
    )
    sec_blocked_trace = [t for t in blocked_security_run["trace"] if t["node_id"] == "security_scan"][0]

    # 3. Assignment 2: Retry Limit & Human Escalation
    # Exceed budget ceiling repeatedly to trigger retry escalation
    retry_graph_engine = GrantNodeGraph()
    escalated_budget_run = retry_graph_engine.execute_graph(
        topic="High-Energy Laser Testbed",
        domain="Electrical Engineering",
        requested_budget=9999999.0, # Exceeds 750,000 cap
        faculty_approved=True
    )
    # Simulate repeated retries to exceed max_retries limit
    budget_node = [n for n in retry_graph_engine.nodes if n.node_id == "budget"][0]
    budget_node.retry_count = 3 # Exceeds max_retries = 2
    retry_escalated_run = retry_graph_engine.execute_graph(
        topic="High-Energy Laser Testbed",
        domain="Electrical Engineering",
        requested_budget=9999999.0,
        faculty_approved=True
    )
    budget_escalated_trace = [t for t in retry_escalated_run["trace"] if t["node_id"] == "budget"][0]

    return {
        "week": 7,
        "title": "Lab 7: Agentic Node Graph -- Declared Contracts, Conditional Routing & Human Escalation",
        "nodes_defined": [
            {
                "node_id": n.node_id,
                "node_name": n.name,
                "owner": n.owner,
                "success_criteria": n.success_criteria,
                "failure_behavior": n.failure_behavior
            }
            for n in graph_engine.nodes
        ],
        "success_execution_trace": success_run,
        "assignment_1_security_scan": {
            "benign_academic_run": sec_cleared_trace,
            "prohibited_dual_use_run": sec_blocked_trace,
            "security_node_effective": sec_cleared_trace["status"] == "SUCCESS" and sec_blocked_trace["status"] == "BLOCKED"
        },
        "assignment_2_retry_escalation": {
            "retry_limit": 2,
            "node_tested": "budget",
            "escalated_trace": budget_escalated_trace,
            "escalated_status": budget_escalated_trace["status"],
            "escalation_passed": budget_escalated_trace["status"] == "ESCALATED_TO_HUMAN"
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week07()
    print(json.dumps(result, indent=2))
