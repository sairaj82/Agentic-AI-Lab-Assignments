import pytest
from labs.week12.lab import run_lab_week12

def test_week12_execution():
    result = run_lab_week12()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 12

def test_week12_assignments():
    result = run_lab_week12()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 12 must contain at least 2 assignment outputs'
