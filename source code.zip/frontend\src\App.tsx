import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { DashboardPage } from './pages/DashboardPage';
import { AgentsPage } from './pages/AgentsPage';
import { OpportunitiesPage } from './pages/OpportunitiesPage';
import { ResearchPage } from './pages/ResearchPage';
import { ProposalsPage } from './pages/ProposalsPage';
import { BudgetPage } from './pages/BudgetPage';
import { CompliancePage } from './pages/CompliancePage';
import { SubmissionPage } from './pages/SubmissionPage';
import { WorkflowPage } from './pages/WorkflowPage';
import { LabsPage } from './pages/LabsPage';
import { LabDetailPage } from './pages/LabDetailPage';
import { api } from './services/api';

export default function App() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [labDetailWeek, setLabDetailWeek] = useState<number | null>(null);

  useEffect(() => {
    api.getStatus().then(setSystemStatus).catch(() => {});
  }, []);

  const handleSetTab = (tab: string) => {
    if (tab !== 'lab-detail') setLabDetailWeek(null);
    setCurrentTab(tab);
  };

  const openLabDetail = (week: number) => {
    setLabDetailWeek(week);
    setCurrentTab('lab-detail');
  };

  const renderPage = () => {
    switch (currentTab) {
      case 'dashboard': return <DashboardPage />;
      case 'agents': return <AgentsPage />;
      case 'opportunities': return <OpportunitiesPage />;
      case 'research': return <ResearchPage />;
      case 'proposals': return <ProposalsPage />;
      case 'budget': return <BudgetPage />;
      case 'compliance': return <CompliancePage />;
      case 'submission': return <SubmissionPage />;
      case 'workflow': return <WorkflowPage />;
      case 'labs': return <LabsPage onOpenDetail={openLabDetail} />;
      case 'lab-detail': return labDetailWeek ? <LabDetailPage week={labDetailWeek} onBack={() => handleSetTab('labs')} /> : <LabsPage onOpenDetail={openLabDetail} />;
      default: return <DashboardPage />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Navigation currentTab={currentTab} setCurrentTab={handleSetTab} systemStatus={systemStatus} />
      <main className="flex-1 ml-72 p-8 overflow-auto">
        {renderPage()}
      </main>
    </div>
  );
}
