import pytest
from labs.week02.lab import run_lab_week02

def test_week02_execution():
    result = run_lab_week02()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 2

def test_week02_assignments():
    result = run_lab_week02()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 2 must contain at least 2 assignment outputs'
