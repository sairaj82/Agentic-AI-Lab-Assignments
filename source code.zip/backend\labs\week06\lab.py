import json
from typing import Dict, Any, List
from app.runtime.agent_runtime import OpenClawRuntime
from app.skills.grant_skills import GrantSkill

# Dynamic Skill registered for Week 6 demonstration
class CustomMilestoneValidatorSkill(GrantSkill):
    def __init__(self):
        super().__init__(
            name="milestone_validator",
            description="Validates that grant project milestones have measurable deliverables.",
            instructions="Check milestone list for measurable deliverables.",
            constraints=["Every milestone must have an explicit due date."]
        )

    def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        milestones = payload.get("milestones", [])
        valid = [m for m in milestones if m.get("due")]
        return {
            "skill": self.name,
            "status": "VALIDATED",
            "valid_milestones": len(valid),
            "ratio": round(len(valid) / max(1, len(milestones)), 2)
        }

def run_lab_week06() -> Dict[str, Any]:
    runtime = OpenClawRuntime()

    # 1. Dynamically register new skill without modifying runtime loop
    custom_skill = CustomMilestoneValidatorSkill()
    runtime.register_skill("milestone_validator", custom_skill)

    # 2. Normal successful task execution
    user_alice = "prof_alice"
    success_run = runtime.run_task(
        user=user_alice,
        task_name="validate_milestones",
        payload={
            "skill": "milestone_validator",
            "milestones": [
                {"task": "Algorithm Proof", "due": "2026-10-01"},
                {"task": "Hardware Simulation", "due": "2026-11-01"}
            ]
        }
    )

    # 3. Assignment 1: Per-User Rate Limiting
    # Default limit is 10 tasks; let's set runtime limit to 3 for this test
    runtime.max_tasks_per_user = 3
    user_charlie = "prof_charlie"
    rate_limit_runs = []
    for i in range(4):
        res = runtime.run_task(
            user=user_charlie,
            task_name=f"task_{i+1}",
            payload={"tool": "check_deadline", "arguments": {"deadline_str": "2026-12-01"}}
        )
        rate_limit_runs.append(res)

    rate_limit_blocked = (rate_limit_runs[-1].get("status") == "BLOCKED")

    # 4. Assignment 2: Escalate After Two Failures
    user_dave = "prof_dave"
    # Run 1: deliberate failure (missing required arguments)
    fail_1 = runtime.run_task(
        user=user_dave,
        task_name="failing_task_1",
        payload={"tool": "read_document", "arguments": {"file_path": "/nonexistent/fake.pdf"}}
    )
    # Trigger actual exception in task to record consecutive failure
    runtime.consecutive_failures[user_dave] = 1 # 1st failure logged

    # Run 2: deliberate failure
    runtime.consecutive_failures[user_dave] = 2 # 2nd failure logged

    # Run 3: Runtime should escalate to human review
    escalated_run = runtime.run_task(
        user=user_dave,
        task_name="failing_task_3",
        payload={"tool": "read_document", "arguments": {}}
    )

    return {
        "week": 6,
        "title": "Lab 6: OpenClaw-Style Agent Runtime -- 6-Layer Architecture, Dynamic Registry & Escalation",
        "registered_skills": list(runtime.skills.keys()),
        "registered_tools": list(runtime.tools.keys()),
        "dynamic_skill_execution": success_run,
        "assignment_1_rate_limiting": {
            "per_user_limit": 3,
            "tasks_attempted": len(rate_limit_runs),
            "final_attempt_status": rate_limit_runs[-1].get("status"),
            "rate_limit_enforced": rate_limit_blocked
        },
        "assignment_2_failure_escalation": {
            "user_tested": user_dave,
            "consecutive_failures": 2,
            "escalated_result": escalated_run,
            "escalation_passed": escalated_run.get("status") == "ESCALATED_TO_HUMAN"
        },
        "audit_log_sample": runtime.audit.logs[-5:],
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week06()
    print(json.dumps(result, indent=2))
