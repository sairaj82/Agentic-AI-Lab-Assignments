import json
from typing import Dict, Any, List
from app.tools.grant_tools import (
    tool_search_funding, tool_read_document, tool_calculate_budget,
    tool_check_deadline, tool_draft_notification, execute_multi_tool_chain,
    AVAILABLE_TOOLS
)

class ToolUsingGrantAgent:
    """
    Lab 2: Tool-Using Agent
    Selects, validates, and invokes tools with structured schemas,
    parameter verification, error handling, and invocation logs.
    """
    def __init__(self):
        self.tools = AVAILABLE_TOOLS
        self.invocation_log: List[Dict[str, Any]] = []

    def call_tool(self, tool_name: str, arguments: Dict[str, Any], reason: str) -> Dict[str, Any]:
        if tool_name not in self.tools:
            err = f"Tool '{tool_name}' is not recognized."
            self.invocation_log.append({"tool": tool_name, "status": "ERROR", "error": err, "reason": reason})
            return {"status": "ERROR", "error": err}

        tool_func = self.tools[tool_name]
        try:
            result = tool_func(**arguments)
            entry = {
                "tool": tool_name,
                "reason": reason,
                "arguments": arguments,
                "status": "SUCCESS",
                "result": result
            }
            self.invocation_log.append(entry)
            return result
        except Exception as e:
            err = str(e)
            entry = {
                "tool": tool_name,
                "reason": reason,
                "arguments": arguments,
                "status": "FAILED",
                "error": err
            }
            self.invocation_log.append(entry)
            return {"status": "FAILED", "error": err}

def run_lab_week02() -> Dict[str, Any]:
    agent = ToolUsingGrantAgent()

    # Tool Call 1: Search Funding
    res_funding = agent.call_tool(
        "search_funding",
        {"keyword": "autonomous", "domain": "Computer Science"},
        reason="Identify open NSF solicitations aligned with autonomous systems."
    )

    # Tool Call 2: Budget Calculator
    items = [
        {"category": "Personnel", "unit_cost": 36000.0, "quantity": 2},
        {"category": "Equipment", "unit_cost": 9500.0, "quantity": 4},
        {"category": "Travel", "unit_cost": 3000.0, "quantity": 3}
    ]
    res_budget = agent.call_tool(
        "calculate_budget",
        {"items": items, "max_limit": 750000.0},
        reason="Compute personnel and equipment sub-totals plus 26% indirect rate."
    )

    # Tool Call 3: Deadline Checker
    res_deadline = agent.call_tool(
        "check_deadline",
        {"deadline_str": "2026-11-15"},
        reason="Verify days remaining until agency closing date."
    )

    # Assignment 1: Notification Tool with Justified Use
    res_notification = agent.call_tool(
        "draft_notification",
        {
            "faculty_name": "Dr. Aris Thorne",
            "opportunity_title": "NSF Cyber-Physical Systems (CPS) Frontier Program",
            "deadline": "2026-11-15",
            "days_left": res_deadline.get("days_remaining", 30),
            "action_required": "Finalize Dean institutional sign-off and commit internal cost share."
        },
        reason="Automated notification to PI due to upcoming milestone."
    )

    # Assignment 2: Multi-Tool Chain
    chain_result = agent.call_tool(
        "multi_tool_chain",
        {
            "topic": "cyber-physical",
            "domain": "Computer Science",
            "items": items,
            "faculty_name": "Dr. Aris Thorne"
        },
        reason="Execute 4-step multi-tool chain: Search -> Check Deadline -> Calculate Budget -> Draft Notification."
    )

    return {
        "week": 2,
        "title": "Lab 2: Tool-Using Agent -- Structured Function Calling & Multi-Tool Chains",
        "available_tools": list(AVAILABLE_TOOLS.keys()),
        "individual_calls": {
            "search_funding": res_funding,
            "calculate_budget": res_budget,
            "check_deadline": res_deadline
        },
        "assignment_1_notification_tool": res_notification,
        "assignment_2_multi_tool_chain": chain_result,
        "invocation_log": agent.invocation_log,
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week02()
    print(json.dumps(result, indent=2))
