import pytest
from labs.week09.lab import run_lab_week09

def test_week09_execution():
    result = run_lab_week09()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 9

def test_week09_assignments():
    result = run_lab_week09()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 9 must contain at least 2 assignment outputs'
