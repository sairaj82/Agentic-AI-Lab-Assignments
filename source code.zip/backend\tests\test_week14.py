import pytest
from labs.week14.lab import run_lab_week14

def test_week14_execution():
    result = run_lab_week14()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 14

def test_week14_assignments():
    result = run_lab_week14()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 14 must contain at least 2 assignment outputs'
