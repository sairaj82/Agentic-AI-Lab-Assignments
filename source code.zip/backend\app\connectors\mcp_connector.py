import os
import json
import sqlite3
import datetime
from typing import Dict, Any, List, Optional
from app.tools.grant_tools import tool_search_funding

SAFE_BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

class MCPCapabilityManifest:
    @staticmethod
    def get_manifest() -> Dict[str, Any]:
        return {
            "protocol_version": "2024-11-05",
            "server_name": "GrantSystem-MCP-Integration-Layer",
            "capabilities": [
                {
                    "name": "read_file",
                    "description": "Safely read document content within authorized project directories.",
                    "parameters": {"path": "string"},
                    "safety": "Sandboxed to project root; path traversal strictly prohibited."
                },
                {
                    "name": "list_files",
                    "description": "List documents in safe project folder.",
                    "parameters": {"folder": "string"},
                    "safety": "Sandboxed to project root."
                },
                {
                    "name": "query_database",
                    "description": "Execute read-only SQL queries against grant_system.db.",
                    "parameters": {"sql_query": "string"},
                    "safety": "Strict SELECT queries only; write and DDL operations blocked."
                },
                {
                    "name": "search_funding",
                    "description": "Query funding agency database for relevant grants.",
                    "parameters": {"keyword": "string", "domain": "string"}
                },
                {
                    "name": "export_grant_manifest",
                    "description": "Export structured JSON package summary for audit or submission.",
                    "parameters": {"project_id": "integer"},
                    "safety": "Sanitized JSON serialization."
                }
            ]
        }

class MCPServer:
    def __init__(self, safe_directory: str = SAFE_BASE_DIR):
        self.safe_dir = os.path.abspath(safe_directory)
        self.db_path = os.path.join(self.safe_dir, "grant_system.db")

    def _validate_safe_path(self, target_path: str) -> str:
        """Enforces safe-directory sandbox (Lab 5 Assignment 2)."""
        abs_path = os.path.abspath(os.path.join(self.safe_dir, target_path) if not os.path.isabs(target_path) else target_path)
        if not abs_path.startswith(self.safe_dir):
            raise PermissionError(f"Security violation: Access outside authorized sandbox denied ({target_path})")
        return abs_path

    def handle_read_file(self, path: str) -> Dict[str, Any]:
        try:
            safe_p = self._validate_safe_path(path)
            if not os.path.exists(safe_p):
                return {"success": False, "error": f"File not found: {path}"}
            with open(safe_p, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            return {"success": True, "path": path, "content": content[:5000], "bytes": len(content)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def handle_list_files(self, folder: str = ".") -> Dict[str, Any]:
        try:
            safe_p = self._validate_safe_path(folder)
            if not os.path.isdir(safe_p):
                return {"success": False, "error": f"Directory not found: {folder}"}
            items = os.listdir(safe_p)
            return {"success": True, "folder": folder, "entries": items[:50]}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def handle_query_database(self, sql_query: str) -> Dict[str, Any]:
        """Executes read-only SQL queries with AST / token keyword blocking."""
        normalized = sql_query.strip().upper()
        prohibited = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "REPLACE", "CREATE", "ATTACH"]
        
        for kw in prohibited:
            # Check whole word match
            if f" {kw} " in f" {normalized} ":
                return {
                    "success": False,
                    "error": f"Security restriction: Prohibited mutation keyword '{kw}' detected. Only SELECT queries are permitted."
                }

        if not normalized.startswith("SELECT"):
            return {
                "success": False,
                "error": "Security restriction: Only queries starting with SELECT are permitted."
            }

        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(sql_query)
            rows = cursor.fetchall()
            results = [dict(row) for row in rows]
            conn.close()
            return {"success": True, "rows_returned": len(results), "data": results[:20]}
        except Exception as e:
            return {"success": False, "error": f"Database error: {str(e)}"}

    def handle_search_funding(self, keyword: str, domain: str = "") -> Dict[str, Any]:
        return tool_search_funding(keyword, domain)

    # Lab 5 Assignment 1: Additional discoverable capability
    def handle_export_grant_manifest(self, project_id: int) -> Dict[str, Any]:
        return {
            "success": True,
            "manifest_type": "GRANT_SUBMISSION_BUNDLE",
            "project_id": project_id,
            "schema_version": "1.0-NSF-COMPLIANT",
            "generated_at": datetime.datetime.now().isoformat()
        }

    def dispatch(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch MCP call with boundary checks."""
        if tool_name == "read_file":
            return self.handle_read_file(arguments.get("path", ""))
        elif tool_name == "list_files":
            return self.handle_list_files(arguments.get("folder", "."))
        elif tool_name == "query_database":
            return self.handle_query_database(arguments.get("sql_query", ""))
        elif tool_name == "search_funding":
            return self.handle_search_funding(arguments.get("keyword", ""), arguments.get("domain", ""))
        elif tool_name == "export_grant_manifest":
            return self.handle_export_grant_manifest(arguments.get("project_id", 1))
        else:
            return {"success": False, "error": f"Unknown capability '{tool_name}'"}

mcp_server = MCPServer()
