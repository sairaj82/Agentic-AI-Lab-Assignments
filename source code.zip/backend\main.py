import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.api.endpoints import router as api_router
from app.database.seed import init_db

app = FastAPI(
    title="Research Grant Management System - Agentic AI",
    description="Full-stack 14-Week Agentic AI College Project for Autonomous Grant Lifecycle Management",
    version="2.0.0"
)

# Enable CORS for local Vite React development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize and seed database if not already seeded
@app.on_event("startup")
def startup_event():
    print("Initializing Research Grant Management System database...")
    init_db()

# Mount API router
app.include_router(api_router, prefix="/api")

@app.get("/")
def root():
    return {
        "message": "Research Grant Management System API is running.",
        "docs": "/docs",
        "health": "/api/status"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
