import io
import datetime
from typing import Dict, Any, List

def generate_proposal_docx(proposal: Dict[str, Any]) -> bytes:
    """Generate a formatted Microsoft Word DOCX document for the proposal draft."""
    import docx
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = docx.Document()

    # Document Title
    title = proposal.get("title", "Research Grant Proposal")
    title_p = doc.add_paragraph()
    title_run = title_p.add_run(title)
    title_run.font.size = Pt(20)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(15, 23, 42)
    title_p.paragraph_format.space_after = Pt(12)

    # Metadata Subtitle
    meta_p = doc.add_paragraph()
    meta_run = meta_p.add_run(
        f"Principal Investigator: {proposal.get('pi_name', 'Faculty Researcher')} | "
        f"Domain: {proposal.get('domain', 'Engineering & Technology')} | "
        f"Generated: {datetime.datetime.now().strftime('%B %d, %Y')}"
    )
    meta_run.font.size = Pt(10)
    meta_run.font.italic = True
    meta_run.font.color.rgb = RGBColor(100, 116, 139)
    meta_p.paragraph_format.space_after = Pt(18)

    # Helper function to add a section
    def add_section(heading: str, content: Any):
        h = doc.add_heading(level=2)
        h_run = h.add_run(heading)
        h_run.font.size = Pt(13)
        h_run.font.bold = True
        h_run.font.color.rgb = RGBColor(30, 58, 138) # Navy blue
        h.paragraph_format.space_before = Pt(12)
        h.paragraph_format.space_after = Pt(4)

        if isinstance(content, list):
            for item in content:
                p = doc.add_paragraph(style='List Bullet')
                p.add_run(str(item))
                p.paragraph_format.space_after = Pt(2)
        elif content:
            p = doc.add_paragraph()
            p.add_run(str(content))
            p.paragraph_format.space_after = Pt(6)

    # Add all 11 sections
    add_section("1. Abstract", proposal.get("abstract"))
    add_section("2. Introduction", proposal.get("introduction"))
    add_section("3. Problem Statement", proposal.get("problem_statement"))
    add_section("4. Research Objectives", proposal.get("objectives"))
    add_section("5. Literature Review", proposal.get("literature_review"))
    add_section("6. Research Gap", proposal.get("research_gap"))
    add_section("7. Methodology", proposal.get("methodology"))
    add_section("8. Expected Outcomes", proposal.get("expected_outcomes"))
    add_section("9. Research Significance & Impact", proposal.get("research_significance"))
    add_section("10. References", proposal.get("references"))

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def generate_proposal_pdf(proposal: Dict[str, Any]) -> bytes:
    """Generate a clean styled PDF document for the proposal draft."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0F172A'),
        spaceAfter=6
    )

    meta_style = ParagraphStyle(
        'DocMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=9,
        leading=12,
        textColor=colors.HexColor('#64748B'),
        spaceAfter=14
    )

    section_heading = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=15,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=10,
        spaceAfter=4
    )

    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor('#1E293B'),
        spaceAfter=6
    )

    story = []

    # Title & Subtitle
    story.append(Paragraph(proposal.get("title", "Research Grant Proposal"), title_style))
    story.append(Paragraph(
        f"Principal Investigator: {proposal.get('pi_name', 'Faculty Researcher')} | "
        f"Domain: {proposal.get('domain', 'Engineering & Technology')} | "
        f"Date: {datetime.datetime.now().strftime('%B %d, %Y')}",
        meta_style
    ))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563EB'), spaceAfter=12))

    def add_pdf_section(title: str, text_or_list: Any):
        story.append(Paragraph(title, section_heading))
        if isinstance(text_or_list, list):
            for it in text_or_list:
                clean_text = f"&bull; {str(it)}"
                story.append(Paragraph(clean_text, body_style))
        elif text_or_list:
            clean_text = str(text_or_list).replace("\n", "<br/>")
            story.append(Paragraph(clean_text, body_style))
        story.append(Spacer(1, 4))

    add_pdf_section("1. Abstract", proposal.get("abstract"))
    add_pdf_section("2. Introduction", proposal.get("introduction"))
    add_pdf_section("3. Problem Statement", proposal.get("problem_statement"))
    add_pdf_section("4. Research Objectives", proposal.get("objectives"))
    add_pdf_section("5. Literature Review", proposal.get("literature_review"))
    add_pdf_section("6. Research Gap", proposal.get("research_gap"))
    add_pdf_section("7. Methodology", proposal.get("methodology"))
    add_pdf_section("8. Expected Outcomes", proposal.get("expected_outcomes"))
    add_pdf_section("9. Research Significance & Impact", proposal.get("research_significance"))
    add_pdf_section("10. References", proposal.get("references"))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def generate_budget_pdf(budget_data: Dict[str, Any]) -> bytes:
    """Generate a clean PDF report for the Budget Plan."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'BudgetTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0F172A'),
        spaceAfter=4
    )

    story = [
        Paragraph("Research Grant Budget Plan & Justification", title_style),
        Paragraph(f"Project ID: {budget_data.get('project_id', 1)} | Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}", styles['Normal']),
        Spacer(1, 10),
        HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#059669'), spaceAfter=14)
    ]

    # Budget table items
    items = budget_data.get("items", [])
    table_data = [["Category", "Description", "Qty", "Unit Cost ($)", "Total ($)", "Justification"]]
    for it in items:
        table_data.append([
            it.get("category", "Personnel"),
            it.get("description", "")[:40],
            str(it.get("quantity", 1)),
            f"${float(it.get('unit_cost', 0)):,.2f}",
            f"${float(it.get('total_cost', 0)):,.2f}",
            it.get("justification", "")[:40]
        ])

    calc = budget_data.get("budget_calculation", {})
    table_data.append(["TOTAL", "Direct + Indirect Costs", "", "", f"${float(calc.get('total_cost', 0)):,.2f}", "Within Ceiling: YES" if calc.get('within_limit', True) else "OVER CEILING"])

    t = Table(table_data, colWidths=[80, 140, 30, 75, 75, 130])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#0F172A')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('BACKGROUND', (0,-1), (-1,-1), colors.HexColor('#F1F5F9')),
        ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
    ]))
    story.append(t)
    story.append(Spacer(1, 14))

    # Justification narrative
    narrative = budget_data.get("justification_narrative", "")
    if narrative:
        story.append(Paragraph("Budget Justification Narrative", styles['Heading2']))
        story.append(Paragraph(narrative.replace("\n", "<br/>"), styles['Normal']))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def generate_compliance_pdf(compliance_data: Dict[str, Any]) -> bytes:
    """Generate a clean PDF report for the Compliance Audit."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()

    story = [
        Paragraph("Grant Compliance & Institutional Audit Report", styles['Heading1']),
        Paragraph(f"Status: {compliance_data.get('overall_compliance_status', 'COMPLIANT')} | Score: {compliance_data.get('overall_score', 100)}/100", styles['Normal']),
        Spacer(1, 8),
        HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#DC2626'), spaceAfter=14)
    ]

    # Checklist table
    docs = compliance_data.get("mandatory_document_checklist", [])
    checklist_data = [["Mandatory Document", "Verification Status", "Institutional Requirement"]]
    for d in docs:
        if isinstance(d, dict):
            checklist_data.append([d.get("document", ""), d.get("status", "VERIFIED"), d.get("requirement", "Federal Standard")])
        else:
            checklist_data.append([str(d), "SUBMITTED & VERIFIED", "Required before submission"])

    if len(checklist_data) > 1:
        t = Table(checklist_data, colWidths=[200, 140, 190])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E293B')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,-1), 8.5),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
        ]))
        story.append(Paragraph("Mandatory Documents & Ethics Clearances", styles['Heading2']))
        story.append(t)
        story.append(Spacer(1, 14))

    # Recommended corrections
    corrections = compliance_data.get("recommended_corrections", [])
    if corrections:
        story.append(Paragraph("Actionable Corrective Recommendations", styles['Heading2']))
        for c in corrections:
            story.append(Paragraph(f"&bull; {str(c)}", styles['Normal']))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def generate_opportunities_pdf(opportunities: List[Dict[str, Any]], topic: str) -> bytes:
    """Generate a clean PDF for Ranked Funding Opportunities."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()

    story = [
        Paragraph("Ranked Grant Funding Opportunities", styles['Heading1']),
        Paragraph(f"Target Research: {topic} | Date: {datetime.datetime.now().strftime('%Y-%m-%d')}", styles['Normal']),
        Spacer(1, 8),
        HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563EB'), spaceAfter=12)
    ]

    table_data = [["Rank", "Agency", "Opportunity Title", "Ceiling", "Deadline", "Relevance", "Recommendation"]]
    for i, opp in enumerate(opportunities[:8], 1):
        table_data.append([
            str(opp.get("ranking", i)),
            opp.get("funding_organization", opp.get("agency", ""))[:12],
            opp.get("funding_opportunity_title", opp.get("title", ""))[:32],
            f"${float(opp.get('funding_amount', opp.get('amount', 0))):,.0f}",
            str(opp.get("deadline", "")),
            f"{float(opp.get('relevance_score', 0)):.1f}%",
            opp.get("reason_for_recommendation", opp.get("recommendation", "Strong Fit"))[:30]
        ])

    t = Table(table_data, colWidths=[30, 65, 160, 65, 60, 50, 110])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
    ]))
    story.append(t)

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
