import React, { useState, useEffect, useCallback } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  Node,
  Edge
} from 'reactflow';
import 'reactflow/dist/style.css';
import { GitFork, Play, Loader2, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { api } from '../services/api';

const initialNodes: Node[] = [
  { id: 'intake', data: { label: '1. Faculty Intake' }, position: { x: 50, y: 150 }, style: { background: '#F8FAFC', border: '2px solid #64748B', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'funding', data: { label: '2. Funding Discovery' }, position: { x: 230, y: 150 }, style: { background: '#EFF6FF', border: '2px solid #3B82F6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'literature', data: { label: '3. Literature Review' }, position: { x: 420, y: 150 }, style: { background: '#EFF6FF', border: '2px solid #3B82F6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'proposal', data: { label: '4. Proposal Drafting' }, position: { x: 610, y: 150 }, style: { background: '#EFF6FF', border: '2px solid #3B82F6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'budget', data: { label: '5. Budget Planning' }, position: { x: 800, y: 150 }, style: { background: '#EFF6FF', border: '2px solid #3B82F6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'compliance', data: { label: '6. Compliance Audit' }, position: { x: 990, y: 150 }, style: { background: '#EFF6FF', border: '2px solid #3B82F6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'security_scan', data: { label: '7. ITAR & Security' }, position: { x: 990, y: 280 }, style: { background: '#F5F3FF', border: '2px solid #8B5CF6', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'human_approval', data: { label: '8. Human Sign-Off' }, position: { x: 800, y: 280 }, style: { background: '#FEF3C7', border: '2px solid #F59E0B', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } },
  { id: 'submission', data: { label: '9. Agency Dispatch' }, position: { x: 610, y: 280 }, style: { background: '#ECFDF5', border: '2px solid #10B981', borderRadius: 8, fontSize: 11, fontWeight: 'bold', padding: 8 } }
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'intake', target: 'funding', animated: true },
  { id: 'e2', source: 'funding', target: 'literature', animated: true },
  { id: 'e3', source: 'literature', target: 'proposal', animated: true },
  { id: 'e4', source: 'proposal', target: 'budget', animated: true },
  { id: 'e5', source: 'budget', target: 'compliance', animated: true },
  { id: 'e6', source: 'compliance', target: 'security_scan', animated: true },
  { id: 'e7', source: 'security_scan', target: 'human_approval', animated: true },
  { id: 'e8', source: 'human_approval', target: 'submission', animated: true }
];

export const WorkflowPage: React.FC = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<any>(null);
  const [executing, setExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);

  const handleRunFullWorkflow = async () => {
    setExecuting(true);
    try {
      const res = await api.runWorkflowGraph(
        'Decentralized Cyber-Physical Verification',
        'Computer Science',
        175000,
        true
      );
      setExecutionResult(res);
    } catch (e: any) {
      alert(`Workflow execution error: ${e.message}`);
    }
    setExecuting(false);
  };

  const onNodeClick = (_: any, node: Node) => {
    setSelectedNode(node);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Agent Workflow Graph</h2>
          <p className="text-slate-500 text-sm mt-1">
            Interactive node-graph visualizer representing the multi-stage autonomous grant lifecycle (React Flow)
          </p>
        </div>
        <button
          onClick={handleRunFullWorkflow}
          disabled={executing}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
        >
          {executing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Executing 9-Node Pipeline...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" /> Execute Full End-to-End Workflow
            </>
          )}
        </button>
      </div>

      {/* Graph Visualizer Canvas */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden h-[420px]">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeClick={onNodeClick}
          fitView
        >
          <Background color="#cbd5e1" gap={16} />
          <Controls />
          <MiniMap />
        </ReactFlow>
      </div>

      {/* Node Inspector or Execution Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <GitFork className="w-4 h-4 text-blue-600" /> Node Inspector
          </h3>
          {selectedNode ? (
            <div className="space-y-2 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
                <span className="text-slate-500 font-medium">Node ID:</span>
                <span className="font-mono font-bold text-slate-800">{selectedNode.id}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
                <span className="text-slate-500 font-medium">Stage Label:</span>
                <span className="font-semibold text-slate-800">{selectedNode.data?.label}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-slate-500 font-medium block mb-1">Declared Contract Input/Output:</span>
                <p className="text-slate-700 font-mono text-[11px]">
                  Requires preceding agent state and emits verified payload for downstream consumption.
                </p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic py-6 text-center">
              Click any node in the graph above to inspect its declared contracts, role, and execution parameters.
            </p>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-indigo-600" /> Execution Results & Trace
          </h3>
          {executionResult ? (
            <pre className="text-xs font-mono text-slate-700 whitespace-pre-wrap max-h-56 overflow-auto bg-slate-50 rounded-lg p-3.5 border border-slate-200">
              {JSON.stringify(executionResult, null, 2)}
            </pre>
          ) : (
            <p className="text-xs text-slate-400 italic py-6 text-center">
              Execute the workflow to view real-time state transitions and stage outputs.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
