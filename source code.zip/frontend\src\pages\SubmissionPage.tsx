import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, AlertTriangle, ShieldAlert, FileCheck, Lock, Loader2, ExternalLink } from 'lucide-react';
import { api } from '../services/api';

export const SubmissionPage: React.FC = () => {
  const [projectId, setProjectId] = useState<number>(1);
  const [loading, setLoading] = useState(true);
  const [preview, setPreview] = useState<any>(null);
  const [facultyApproved, setFacultyApproved] = useState(false);
  const [approverName, setApproverName] = useState('Dr. Aris Thorne');
  const [submitting, setSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<any>(null);

  const loadPreview = async () => {
    try {
      const data = await api.getSubmissionPreview(projectId);
      setPreview(data);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    loadPreview();
  }, [projectId]);

  const handleSubmit = async () => {
    if (!facultyApproved) {
      alert('Governance Rule Violation: Human-in-the-Loop policy strictly forbids automated grant submission without explicit faculty PI authorization.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.approveAndSubmit(projectId, facultyApproved, approverName);
      setSubmissionResult(res);
      await loadPreview();
    } catch (e: any) {
      alert(`Submission failed: ${e.message}`);
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const pkg = preview?.package || {};
  const isAlreadySubmitted = preview?.existing_record?.status === 'Submitted' || submissionResult?.status === 'SUBMITTED';

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Submission Centre</h2>
        <p className="text-slate-500 text-sm mt-1">
          Final package review, governance verification, and human-authorized dispatch to agency portal
        </p>
      </div>

      {/* Submission Success Banner */}
      {isAlreadySubmitted && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6 shadow-sm flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">Grant Successfully Submitted</span>
            <h3 className="text-lg font-bold text-emerald-950 mt-0.5">
              Tracking Number: {submissionResult?.tracking_number || preview?.existing_record?.tracking_number || 'GRANT-NSF-2025-0981'}
            </h3>
            <p className="text-xs text-emerald-800 mt-1">
              Authorized by {submissionResult?.approved_by || preview?.existing_record?.approved_by || approverName}. Full package archived and sealed.
            </p>
          </div>
        </div>
      )}

      {/* Package Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-blue-600" /> Grant Submission Package Preview
            </h3>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold font-mono">
              Bundle ID: {pkg.package_id || 'PKG-1001'}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
              <span className="text-slate-500 font-medium">Proposal Title:</span>
              <span className="text-slate-900 font-semibold max-w-[70%] text-right truncate">
                {pkg.proposal_data?.title || 'Multi-Agent Autonomous Verification Systems'}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
              <span className="text-slate-500 font-medium">Principal Investigator:</span>
              <span className="text-slate-900 font-semibold">{pkg.proposal_data?.pi_name || approverName}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
              <span className="text-slate-500 font-medium">Requested Funding:</span>
              <span className="text-slate-900 font-bold font-mono">
                ${(pkg.budget_data?.budget_calculation?.total_cost || 175000).toLocaleString()}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex justify-between">
              <span className="text-slate-500 font-medium">Compliance Audit Score:</span>
              <span className="text-emerald-700 font-bold font-mono">
                {pkg.compliance_data?.overall_score || 92}% Passed
              </span>
            </div>
          </div>

          {/* Submission Checklist */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Pre-Flight Verification Checklist</h4>
            <div className="space-y-2">
              {[
                { label: 'Project Description & Specific Aims Formatted', ok: true },
                { label: 'Institutional Indirect Rate (F&A) Certified', ok: true },
                { label: 'Key Personnel Biographical Sketches Attached', ok: true },
                { label: 'Conflict of Interest & Current/Pending Disclosed', ok: true },
                { label: 'Data Management & Open Access Plan Included', ok: true }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Human Governance Approval Box */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Human-in-the-Loop Gate</h3>
            </div>

            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-amber-800">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" /> Autonomous Submission Restricted
              </div>
              <p className="text-[11px] leading-relaxed">
                Antigravity Governance Rule 12-B: No agent may transmit binding grants without explicit human signature.
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <div>
                <label className="text-xs font-semibold text-slate-600">Authorized Faculty Signer</label>
                <input
                  type="text"
                  value={approverName}
                  onChange={e => setApproverName(e.target.value)}
                  disabled={isAlreadySubmitted}
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                />
              </div>

              <label className="flex items-start gap-2 cursor-pointer pt-2">
                <input
                  type="checkbox"
                  checked={facultyApproved}
                  onChange={e => setFacultyApproved(e.target.checked)}
                  disabled={isAlreadySubmitted}
                  className="mt-0.5 w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <span className="text-xs text-slate-700 font-medium">
                  I explicitly certify this research grant proposal package and authorize final agency dispatch.
                </span>
              </label>
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={!facultyApproved || submitting || isAlreadySubmitted}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-blue-600 text-white text-sm font-bold hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 transition shadow-md shadow-blue-500/20"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Transmitting Package...
              </>
            ) : isAlreadySubmitted ? (
              <>
                <CheckCircle2 className="w-4 h-4" /> Package Dispatched
              </>
            ) : (
              <>
                <Send className="w-4 h-4" /> Authorize & Submit Grant
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
