import pytest
from labs.week04.lab import run_lab_week04

def test_week04_execution():
    result = run_lab_week04()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 4

def test_week04_assignments():
    result = run_lab_week04()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 4 must contain at least 2 assignment outputs'
