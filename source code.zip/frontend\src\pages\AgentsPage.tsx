import React, { useEffect, useState } from 'react';
import { Bot, Play, Loader2, CheckCircle2, AlertTriangle, ChevronDown, ChevronUp, Terminal } from 'lucide-react';
import { api } from '../services/api';

const STATUS_COLORS: Record<string, string> = {
  IDLE: 'bg-slate-100 text-slate-600',
  WORKING: 'bg-blue-100 text-blue-700 animate-pulse',
  SUCCESS: 'bg-green-100 text-green-700',
  ERROR: 'bg-red-100 text-red-700'
};

export const AgentsPage: React.FC = () => {
  const [agents, setAgents] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningId, setRunningId] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, any>>({});
  const [showLogs, setShowLogs] = useState(false);

  useEffect(() => {
    Promise.all([api.getAgents(), api.getAgentLogs()])
      .then(([a, l]) => {
        setAgents(a);
        setLogs(l);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const runAgent = async (agentId: string) => {
    setRunningId(agentId);
    try {
      const res = await api.runAgent(agentId, 1, {
        topic: 'Multi-Agent Systems for Cyber-Physical Verification',
        domain: 'Computer Science'
      });
      setResults(prev => ({ ...prev, [agentId]: res }));
      const newLogs = await api.getAgentLogs();
      setLogs(newLogs);
    } catch (err: any) {
      setResults(prev => ({ ...prev, [agentId]: { error: err.message } }));
    }
    setRunningId(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">AI Agents Dashboard</h2>
          <p className="text-slate-500 text-sm mt-1">
            Monitor, execute, and inspect the six autonomous grant lifecycle agents
          </p>
        </div>
        <button
          onClick={() => setShowLogs(!showLogs)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
        >
          <Terminal className="w-4 h-4 text-slate-500" />
          {showLogs ? 'Hide' : 'Show'} Execution Logs
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {agents.map(agent => {
          const isRunning = runningId === agent.id;
          const isExpanded = expanded === agent.id;
          const result = results[agent.id];
          return (
            <div
              key={agent.id}
              className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div className="p-5 flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/20">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-900 text-sm">{agent.name}</h3>
                      <p className="text-xs text-slate-400">{agent.role}</p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wide ${
                      STATUS_COLORS[isRunning ? 'WORKING' : agent.status] || STATUS_COLORS.IDLE
                    }`}
                  >
                    {isRunning ? 'WORKING' : agent.status}
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">{agent.description}</p>
              </div>

              <div className="px-5 pb-4 space-y-2">
                <button
                  onClick={() => runAgent(agent.id)}
                  disabled={isRunning}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
                >
                  {isRunning ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Executing Agent...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-white" /> Execute Agent
                    </>
                  )}
                </button>
                {result && (
                  <button
                    onClick={() => setExpanded(isExpanded ? null : agent.id)}
                    className="w-full flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50 transition"
                  >
                    {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    {isExpanded ? 'Hide Output' : 'Inspect Output'}
                  </button>
                )}
              </div>

              {isExpanded && result && (
                <div className="border-t border-slate-100 px-5 py-3 bg-slate-50 rounded-b-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Output Trace</span>
                    <span className="text-[10px] text-slate-400">{result.execution_time_sec ? `${result.execution_time_sec}s` : 'Success'}</span>
                  </div>
                  <pre className="text-[11px] font-mono text-slate-700 overflow-auto max-h-56 whitespace-pre-wrap bg-white p-3 rounded-lg border border-slate-200">
                    {JSON.stringify(result, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {showLogs && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-blue-500" /> Agent Execution History & Audit Logs
          </h3>
          {logs.length === 0 ? (
            <p className="text-sm text-slate-400 italic">No execution logs yet. Run an agent to generate logs.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left text-slate-400 border-b border-slate-100">
                    <th className="pb-2.5 pr-4">Agent Name</th>
                    <th className="pb-2.5 pr-4">Task Description</th>
                    <th className="pb-2.5 pr-4">Status</th>
                    <th className="pb-2.5 pr-4">Execution Time</th>
                    <th className="pb-2.5">Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.slice(0, 15).map((log: any, i: number) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                      <td className="py-2.5 pr-4 font-medium text-slate-800">{log.agent_name}</td>
                      <td className="py-2.5 pr-4 text-slate-500">{log.task_name}</td>
                      <td className="py-2.5 pr-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            log.status === 'SUCCESS' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {log.status}
                        </span>
                      </td>
                      <td className="py-2.5 pr-4 text-slate-500 font-mono">{log.execution_time_sec ? `${log.execution_time_sec}s` : '—'}</td>
                      <td className="py-2.5 text-slate-400 font-mono">{log.created_at || 'Just now'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
