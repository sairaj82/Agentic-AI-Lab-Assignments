import json
from typing import Dict, Any, List
from app.workflows.sdlc_factory import SDLCFactory

def run_lab_week11() -> Dict[str, Any]:
    factory = SDLCFactory()

    # 1. Normal clean feature release
    clean_pipeline = factory.run_sdlc_pipeline(
        feature_name="Proposal Multi-Format Exporter (JSON/Markdown/PDF)",
        inject_deliberate_bug=False
    )

    # 2. Assignment 2: Prove Test Independence with Deliberate Bug Injection
    buggy_pipeline = factory.run_sdlc_pipeline(
        feature_name="Proposal Multi-Format Exporter with Regression",
        inject_deliberate_bug=True
    )

    # Assignment 1: Inspect Security Scanning Node
    sec_node_clean = [s for s in clean_pipeline["pipeline_log"] if s["stage"] == "Security Scanning"][0]

    # Inspect Testing Node for both runs
    test_clean = [s for s in clean_pipeline["pipeline_log"] if s["stage"] == "Quality Assurance & Unit Testing"][0]
    test_buggy = [s for s in buggy_pipeline["pipeline_log"] if s["stage"] == "Quality Assurance & Unit Testing"][0]

    return {
        "week": 11,
        "title": "Lab 11: Agentic SDLC Factory -- Autonomous Software Engineering & Independent Test Verification",
        "clean_release_pipeline": clean_pipeline,
        "assignment_1_security_scan_node": {
            "stage": sec_node_clean["stage"],
            "agent": sec_node_clean["agent"],
            "status": sec_node_clean["status"],
            "output": sec_node_clean["output"],
            "passed": sec_node_clean["status"] == "PASSED"
        },
        "assignment_2_test_independence_bug_injection": {
            "clean_test_status": test_clean["status"],
            "buggy_test_status": test_buggy["status"],
            "caught_deliberate_bug": test_buggy["status"] == "FAILED",
            "caught_error_message": test_buggy.get("error"),
            "review_agent_blocked_release": buggy_pipeline["overall_status"] == "BUILD_FAILED_ESCALATED"
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week11()
    print(json.dumps(result, indent=2))
