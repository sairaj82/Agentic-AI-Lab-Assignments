import pytest
from labs.week08.lab import run_lab_week08

def test_week08_execution():
    result = run_lab_week08()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 8

def test_week08_assignments():
    result = run_lab_week08()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 8 must contain at least 2 assignment outputs'
