import datetime
from app.database.session import SessionLocal, engine, Base
from app.database.models import (
    Faculty, GrantOpportunity, ResearchProject, BudgetItem, 
    ComplianceCheck, ProposalDraft, SubmissionRecord, LabRecord
)

def init_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(Faculty).first():
            print("Database already contains data. Skipping seed.")
            return

        print("Seeding database with initial faculty, opportunities and lab templates...")

        # 1. Seed Faculty
        f1 = Faculty(
            name="Dr. Aris Thorne",
            email="aris.thorne@university.edu",
            department="Computer Science & Engineering",
            research_domain="Computer Science",
            bio="Associate Professor focusing on Multi-Agent Systems, Safe Autonomous AI, and Distributed Consensus."
        )
        f2 = Faculty(
            name="Dr. Elena Rostova",
            email="elena.rostova@university.edu",
            department="Electrical & Computer Engineering",
            research_domain="Electrical Engineering",
            bio="Professor specializing in Smart Grid Resiliency, Renewable Energy Integration, and Power Electronics."
        )
        f3 = Faculty(
            name="Dr. Marcus Vance",
            email="marcus.vance@university.edu",
            department="Mechanical & Aerospace Engineering",
            research_domain="Mechanical Engineering",
            bio="Lead Researcher in Autonomous Robotics, Predictive Maintenance, and High-Precision Sensing."
        )
        f4 = Faculty(
            name="Dr. Sarah Lin",
            email="sarah.lin@university.edu",
            department="Civil & Environmental Engineering",
            research_domain="Civil Engineering",
            bio="Expert in Sustainable Urban Infrastructure, Earthquake Mitigation, and Smart Concrete Sensing."
        )
        db.add_all([f1, f2, f3, f4])
        db.commit()

        # 2. Seed Grant Opportunities
        g1 = GrantOpportunity(
            title="NSF Cyber-Physical Systems (CPS) Frontier Program",
            agency="National Science Foundation (NSF)",
            amount=750000.0,
            deadline="2026-11-15",
            domain="Computer Science",
            eligibility="Accredited US higher education institutions; Tenure-track PI required; Indirect cost cap 26%.",
            description="Supports transformative research across computer science, networking, and control engineering for intelligent autonomous cyber-physical systems.",
            url="https://nsf.gov/funding/cps-frontier",
            status="Open",
            relevance_score=94.5
        )
        g2 = GrantOpportunity(
            title="DOE Grid Modernization & Renewable Integration Grant",
            agency="Department of Energy (DOE)",
            amount=1200000.0,
            deadline="2026-12-01",
            domain="Electrical Engineering",
            eligibility="University-industry partnerships; 20% institutional cost sharing; Zero-carbon emission focus.",
            description="Accelerates deployment of AI-managed microgrids and fault-tolerant power electronics for high-penetration renewable energy.",
            url="https://energy.gov/eere/grid-modernization",
            status="Open",
            relevance_score=91.0
        )
        g3 = GrantOpportunity(
            title="DARPA Safe Autonomous Robotics & Teleoperation",
            agency="DARPA",
            amount=1500000.0,
            deadline="2027-01-20",
            domain="Mechanical Engineering",
            eligibility="US entities; Strict ITAR compliance; Advanced hardware safety guarantees required.",
            description="Investigates real-time verification and predictive maintenance architectures for robotic swarms in mission-critical environments.",
            url="https://darpa.mil/program/safe-robotics",
            status="Open",
            relevance_score=88.0
        )
        g4 = GrantOpportunity(
            title="DOT Sustainable Infrastructure & Smart Materials Initiative",
            agency="Department of Transportation (DOT)",
            amount=650000.0,
            deadline="2026-11-30",
            domain="Civil Engineering",
            eligibility="Academic civil engineering departments; Environmental impact statement required.",
            description="Develops sensor-embedded smart structural materials and automated vibration monitoring for bridge and highway resilience.",
            url="https://transportation.gov/grants/smart-infrastructure",
            status="Open",
            relevance_score=86.5
        )
        g5 = GrantOpportunity(
            title="NIH Biomedical Data Intelligence & Edge Agent Systems",
            agency="National Institutes of Health (NIH)",
            amount=850000.0,
            deadline="2026-12-15",
            domain="Computer Science",
            eligibility="Requires IRB/human subject ethical approval clearance; HIPAA-compliant agent pipelines.",
            description="Explores edge-computing multi-agent architectures for federated, privacy-preserving clinical diagnostics.",
            url="https://nih.gov/grants/biomed-edge-agents",
            status="Open",
            relevance_score=82.0
        )
        db.add_all([g1, g2, g3, g4, g5])
        db.commit()

        # 3. Seed Initial Research Project
        p1 = ResearchProject(
            faculty_id=f1.id,
            title="Decentralized Multi-Agent Coordination for Resilient Cyber-Physical Networks",
            domain="Computer Science",
            topic="Agentic AI verification and consensus protocols in distributed autonomous grids",
            abstract="This project explores verified multi-agent communication topologies to guarantee zero-deadlock state coordination in high-stress edge computing scenarios.",
            status="Drafting"
        )
        db.add(p1)
        db.commit()

        # 4. Seed Proposal Draft
        prop = ProposalDraft(
            project_id=p1.id,
            version=1,
            title="Decentralized Multi-Agent Coordination for Resilient Cyber-Physical Networks",
            abstract=p1.abstract,
            introduction="Recent breakthroughs in autonomous systems have highlighted the transformative potential of multi-agent intelligence across cyber-physical infrastructure. However, real-time coordination remains vulnerable to packet loss, latency jitter, and lack of formal safety contracts.",
            problem_statement="Current distributed architectures lack mathematically verifiable bounds for agent interaction. Under high throughput and asymmetric network degradation, uncoordinated state transitions induce systemic deadlocks.",
            objectives=[
                "Formalize mathematical constraints for real-time agent peer consensus under adversarial packet loss.",
                "Build an open-source testbed validating 50+ concurrent swarm nodes with verifiable safety contracts.",
                "Deploy and benchmark latency and compute footprint against traditional monolithic controller nodes."
            ],
            literature_review="Recent breakthroughs by Russell (2024) and Wooldridge (2023) emphasize runtime self-reflection. However, a prominent research gap exists in distributed consensus under non-deterministic network latency.",
            research_gap="Verified absence of hybrid neuro-symbolic coordination frameworks combining runtime formal safety shields with high-throughput distributed agent consensus.",
            methodology="We apply a hybrid neuro-symbolic agent architecture where high-level policy generation is mediated through verifiable state-action graphs and bounded constraint solvers across three structured experimental phases.",
            expected_outcomes=[
                "Deterministic fail-safe guarantees for multi-agent autonomous clusters.",
                "Three peer-reviewed conference publications in IEEE/ACM transactions.",
                "Fully open-source reference agent runtime implementation."
            ],
            research_significance="Foundational impact on critical national infrastructure, smart electric grids, and autonomous robotic swarms, guaranteeing zero deadlock under bounded communications latency.",
            references=[
                "Thorne, A., et al. (2024). 'Verifiable Swarm Intelligence: Foundations and Future Directions', IEEE Trans. AI, 12(3), 450-468.",
                "Vaswani, A., et al. (2023). 'Attention and Coordination in Multi-Agent Contexts', ACM Computing Surveys, 55(2), 1-34.",
                "Russell, S., & Wooldridge, M. (2024). 'Safe Autonomous Worklets and Formal Proof Envelopes', Academic Press."
            ],
            full_draft="Comprehensive Grant Proposal Draft\n\nTitle: Decentralized Multi-Agent Coordination for Resilient Cyber-Physical Networks\nPrincipal Investigator: Dr. Aris Thorne\nDomain: Computer Science\n\n1. Executive Summary\nModern cyber-physical networks require autonomous adaptation without central bottlenecks...\n\n2. Objectives & Innovation\n...",
        )
        db.add(prop)

        # 5. Seed Budget Items
        b1 = BudgetItem(
            project_id=p1.id,
            category="Personnel",
            description="Graduate Research Assistant (2 PhD students, 24 months stipend)",
            quantity=2,
            unit_cost=36000.0,
            total_cost=72000.0,
            justification="PhD students will execute the core formal verification theorems and implement the agent node testbed."
        )
        b2 = BudgetItem(
            project_id=p1.id,
            category="Equipment",
            description="High-Throughput Edge GPU Computing Nodes (4x NVIDIA RTX 6000 Ada)",
            quantity=4,
            unit_cost=9500.0,
            total_cost=38000.0,
            justification="Required for local execution of agentic LLM fine-tuning, latency benchmarking, and swarm emulation."
        )
        b3 = BudgetItem(
            project_id=p1.id,
            category="Travel",
            description="Conference Dissemination (NeurIPS, ICRA, AAMAS)",
            quantity=3,
            unit_cost=3000.0,
            total_cost=9000.0,
            justification="To present findings and disseminate open-source benchmark suites to the international community."
        )
        b4 = BudgetItem(
            project_id=p1.id,
            category="Consumables",
            description="Cloud Vector Database & Storage Credits",
            quantity=1,
            unit_cost=6000.0,
            total_cost=6000.0,
            justification="ChromaDB persistent hosting, telemetry indexing, and large dataset distribution."
        )
        b5 = BudgetItem(
            project_id=p1.id,
            category="Indirect",
            description="Institutional Overhead (26% rate on eligible personnel and direct costs)",
            quantity=1,
            unit_cost=32500.0,
            total_cost=32500.0,
            justification="Mandated university facilities and administrative support rate."
        )
        db.add_all([b1, b2, b3, b4, b5])

        # 6. Seed Compliance Check
        c1 = ComplianceCheck(
            project_id=p1.id,
            overall_score=92.0,
            eligibility_status="Passed",
            budget_status="Passed",
            missing_documents=["Data Management Plan signed by Department Head"],
            ethics_approval_needed=False,
            warnings=["Indirect cost rate matches the 26% cap exactly. Ensure no fringe benefit calculation mismatch."],
            check_report="Full compliance audit completed. The proposal adheres to NSF CPS guidelines with verified personnel eligibility and standard budget ceilings."
        )
        db.add(c1)

        # 7. Seed Submission Record
        s1 = SubmissionRecord(
            project_id=p1.id,
            package_json={
                "project_title": p1.title,
                "pi": "Dr. Aris Thorne",
                "funding_agency": "NSF",
                "requested_budget": 157500.0,
                "sections_ready": ["Abstract", "Objectives", "Methodology", "Budget Justification", "Literature Review"],
                "compliance_score": 92.0
            },
            checklist=[
                {"item": "Proposal Abstract & Project Description", "completed": True},
                {"item": "Detailed Itemized Budget", "completed": True},
                {"item": "Biographical Sketch of PI", "completed": True},
                {"item": "Compliance & Ethics Clearances", "completed": True},
                {"item": "Data Management & Sharing Plan", "completed": False},
                {"item": "Final Institutional Authorization", "completed": False}
            ],
            faculty_approved=False,
            status="Pending Review"
        )
        db.add(s1)

        db.commit()
        print("Database seeding completed successfully.")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    init_db()
