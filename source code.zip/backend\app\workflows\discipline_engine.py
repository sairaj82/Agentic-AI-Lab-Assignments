import datetime
from typing import Dict, Any, List

DOMAIN_PROFILES = {
    "Computer Science": {
        "keywords": ["multi-agent systems", "consensus algorithms", "formal verification", "cybersecurity", "distributed edge"],
        "target_agencies": ["NSF CISE", "DARPA", "NIH Biomedical Informatics"],
        "budget_emphasis": "High-compute GPU workstations, cloud credits, and doctoral research assistant stipends.",
        "compliance_rules": ["Open-source software license (MIT/Apache)", "Data management plan for training datasets", "Zero ITAR dual-use violations"],
        "sample_project": "Decentralized Multi-Agent Coordination for Resilient Cyber-Physical Networks"
    },
    "Electrical Engineering": {
        "keywords": ["smart grid resilience", "high-penetration renewable", "wide-bandgap power inverters", "frequency regulation"],
        "target_agencies": ["DOE EERE", "ARPA-E", "NSF Engineering"],
        "budget_emphasis": "Power hardware-in-the-loop (PHIL) simulators, oscilloscope probes, and cleanroom testbed access.",
        "compliance_rules": ["IEEE 1547 grid interconnection compliance", "High-voltage laboratory safety clearance"],
        "sample_project": "Fault-Tolerant Microgrid Inverters with Autonomous Black-Start Capabilities"
    },
    "Mechanical Engineering": {
        "keywords": ["autonomous robotics", "predictive maintenance", "finite element analysis", "actuator dynamics", "tactile sensing"],
        "target_agencies": ["NSF CMMI", "DARPA Robotics", "NIST"],
        "budget_emphasis": "Precision CNC milling, multi-axis robotic arms, load cells, and rapid prototyping materials.",
        "compliance_rules": ["OSHA laboratory mechanical safety clearance", "ITAR physical robotics export classification"],
        "sample_project": "Bio-Inspired Robotic Swarms for Non-Destructive Structural Inspection"
    },
    "Civil Engineering": {
        "keywords": ["sustainable infrastructure", "smart concrete", "seismic attenuation", "structural health monitoring"],
        "target_agencies": ["DOT", "NSF Civil Infrastructure", "FHWA"],
        "budget_emphasis": "Environmental chamber testing, fiber-optic strain gauges, and field site travel.",
        "compliance_rules": ["NEPA environmental impact assessment", "State DOT site-access authorization"],
        "sample_project": "Carbon-Negative Smart Concrete Embedded with Real-Time Micro-Strain Telemetry"
    }
}

class DisciplineEngineeringEngine:
    def adapt_domain(self, domain: str, topic: str, historical_budget_changes: List[float] = []) -> Dict[str, Any]:
        profile = DOMAIN_PROFILES.get(domain, DOMAIN_PROFILES["Computer Science"])

        # Check Trend-Based Escalation (Lab 13 Assignment 2)
        # Escalates if budget or compliance alterations trend upward consecutively
        escalation_triggered = False
        escalation_reason = ""
        if len(historical_budget_changes) >= 3:
            # check if last 3 iterations increased budget requests monotonically
            if historical_budget_changes[-1] > historical_budget_changes[-2] > historical_budget_changes[-3]:
                escalation_triggered = True
                escalation_reason = (
                    f"Trend-based risk alert: Consecutive monotonic budget inflation detected "
                    f"({historical_budget_changes[-3]} -> {historical_budget_changes[-2]} -> {historical_budget_changes[-1]}). "
                    f"Directing to Department Chair fiscal audit."
                )

        return {
            "domain": domain,
            "topic": topic,
            "profile": profile,
            "domain_adapted_objectives": [
                f"Develop mathematical models tailored to {domain} principles.",
                f"Perform empirical benchmarking matching {profile['target_agencies'][0]} standards.",
                f"Ensure institutional alignment with {profile['compliance_rules'][0]}."
            ],
            "budget_guidelines": profile["budget_emphasis"],
            "compliance_requirements": profile["compliance_rules"],
            "trend_escalation_triggered": escalation_triggered,
            "escalation_reason": escalation_reason,
            "adapted_at": datetime.datetime.now().isoformat()
        }

discipline_engine = DisciplineEngineeringEngine()
