import json
from typing import Dict, Any, List
from app.workflows.system_diagnosis import SystemDiagnosisAgent

def run_lab_week10() -> Dict[str, Any]:
    agent = SystemDiagnosisAgent()

    # Incident 1: PDF Processing Failure (WARNING severity -> Safe auto-remediation applies)
    pdf_log = (
        "ERROR: pypdf.errors.PdfStreamError: Stream has unreadable Huffman table in Object 14. "
        "Failed to extract text from grant solicitation guideline."
    )
    inc_1 = agent.diagnose_incident("PDF_EXTRACTION_FAILURE", pdf_log)

    # Assignment 1: Database Connection Pool Exhaustion / SQLite Lock (ALARM severity)
    db_log = (
        "CRITICAL: sqlite3.OperationalError: database is locked. "
        "Pool timeout: 12 concurrent worker agent threads exhausted connection limit while logging telemetry."
    )
    inc_2 = agent.diagnose_incident("DATABASE_LOCK_EXHAUSTION", db_log)

    # Incident 3: API Latency / Timeout (WARNING severity)
    api_log = "WARNING: requests.exceptions.ReadTimeout: Federal grant agency endpoint /solicitations timed out after 5000ms."
    inc_3 = agent.diagnose_incident("GRANT_API_TIMEOUT", api_log)

    return {
        "week": 10,
        "title": "Lab 10: Cloud Operations Agent -- Observability, Root-Cause Diagnosis & Severity-Gated Remediation",
        "incidents_diagnosed": [inc_1, inc_2, inc_3],
        "assignment_1_database_pool_incident": {
            "incident_id": inc_2["incident_id"],
            "severity": inc_2["severity"],
            "root_cause": inc_2["root_cause"],
            "remediation_plan": inc_2["remediation_plan"],
            "human_approval_required": inc_2["human_approval_required"]
        },
        "assignment_2_safe_auto_remediation": {
            "warning_incident_auto_remediated": inc_1["safe_auto_executable"],
            "alarm_incident_requires_human_approval": inc_2["human_approval_required"],
            "safety_gate_passed": inc_1["safe_auto_executable"] is True and inc_2["safe_auto_executable"] is False
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week10()
    print(json.dumps(result, indent=2))
