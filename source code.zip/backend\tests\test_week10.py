import pytest
from labs.week10.lab import run_lab_week10

def test_week10_execution():
    result = run_lab_week10()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 10

def test_week10_assignments():
    result = run_lab_week10()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 10 must contain at least 2 assignment outputs'
