from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class FacultySchema(BaseModel):
    id: Optional[int] = None
    name: str
    email: str
    department: str
    research_domain: str
    bio: Optional[str] = None

class GrantOpportunitySchema(BaseModel):
    id: Optional[int] = None
    title: str
    agency: str
    amount: float
    deadline: str
    domain: str
    eligibility: str
    description: str
    url: Optional[str] = None
    status: Optional[str] = "Open"
    relevance_score: Optional[float] = 0.0

class BudgetItemSchema(BaseModel):
    id: Optional[int] = None
    project_id: int
    category: str
    description: str
    quantity: int = 1
    unit_cost: float
    total_cost: float
    justification: Optional[str] = None

class BudgetCalculationRequest(BaseModel):
    project_id: int
    max_budget_limit: Optional[float] = 1000000.0
    items: List[BudgetItemSchema] = []

class ProposalDraftSchema(BaseModel):
    id: Optional[int] = None
    project_id: int
    version: int = 1
    title: str
    abstract: Optional[str] = None
    introduction: Optional[str] = None
    problem_statement: Optional[str] = None
    objectives: Optional[List[str]] = None
    literature_review: Optional[str] = None
    research_gap: Optional[str] = None
    methodology: Optional[str] = None
    expected_outcomes: Optional[List[str]] = None
    research_significance: Optional[str] = None
    references: Optional[List[str]] = None
    full_draft: Optional[str] = None

class ResearchProjectCreate(BaseModel):
    faculty_id: Optional[int] = None
    title: str
    domain: str = "Computer Science"
    topic: str
    abstract: Optional[str] = None

class ComplianceCheckResponse(BaseModel):
    project_id: int
    overall_score: float
    eligibility_status: str
    budget_status: str
    missing_documents: List[str]
    ethics_approval_needed: bool
    warnings: List[str]
    check_report: str

class SubmissionActionRequest(BaseModel):
    project_id: int
    faculty_approved: bool
    approved_by: Optional[str] = None

class AgentRunRequest(BaseModel):
    agent_id: str
    project_id: Optional[int] = None
    parameters: Dict[str, Any] = {}

class LabRunRequest(BaseModel):
    week_number: int
    user_input: Optional[str] = None
    custom_input: Optional[Dict[str, Any]] = None
    run_assignments: bool = True
