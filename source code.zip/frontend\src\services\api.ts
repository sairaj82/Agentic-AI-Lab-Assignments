const API_BASE = '/api';

export async function fetchApi<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  const response = await fetch(url, {
    ...options,
    headers: options.body instanceof FormData ? undefined : headers
  });

  if (!response.ok) {
    let errMessage = `HTTP error ${response.status}: ${response.statusText}`;
    try {
      const errJson = await response.json();
      if (errJson.detail) errMessage = errJson.detail;
    } catch {
      // ignore
    }
    throw new Error(errMessage);
  }

  return response.json();
}

export const api = {
  // System & Stats
  getStatus: () => fetchApi<any>('/status'),
  getDashboardStats: () => fetchApi<any>('/dashboard/stats'),

  // Opportunities
  getOpportunities: (domain?: string, keyword?: string) => {
    const params = new URLSearchParams();
    if (domain && domain !== 'All') params.append('domain', domain);
    if (keyword) params.append('keyword', keyword);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return fetchApi<any[]>(`/opportunities${qs}`);
  },
  createOpportunity: (opp: any) => fetchApi<any>('/opportunities', { method: 'POST', body: JSON.stringify(opp) }),
  updateOpportunity: (id: number, opp: any) => fetchApi<any>(`/opportunities/${id}`, { method: 'PUT', body: JSON.stringify(opp) }),
  deleteOpportunity: (id: number) => fetchApi<any>(`/opportunities/${id}`, { method: 'DELETE' }),
  rankOpportunities: (topic: string, domain: string) => fetchApi<any>('/opportunities/rank', { method: 'POST', body: JSON.stringify({ topic, domain }) }),

  // Faculty & Research
  getFaculty: () => fetchApi<any[]>('/faculty'),
  getProjects: () => fetchApi<any[]>('/research/projects'),
  createProject: (data: any) => fetchApi<any>('/research/projects', { method: 'POST', body: JSON.stringify(data) }),
  uploadDocument: (projectId: number, file: File) => {
    const formData = new FormData();
    formData.append('project_id', projectId.toString());
    formData.append('file', file);
    return fetchApi<any>('/research/upload', { method: 'POST', body: formData });
  },
  runLiteratureReview: (projectId: number, topic: string, extractedText?: string) =>
    fetchApi<any>('/research/literature-review', { method: 'POST', body: JSON.stringify({ project_id: projectId, topic, extracted_text: extractedText }) }),

  // Proposals
  getProposals: (projectId?: number) => fetchApi<any[]>(projectId ? `/proposals?project_id=${projectId}` : '/proposals'),
  generateProposal: (projectId: number, topic: string, domain: string, piName: string) =>
    fetchApi<any>('/proposals/generate', { method: 'POST', body: JSON.stringify({ project_id: projectId, topic, domain, pi_name: piName }) }),
  updateProposal: (draftId: number, data: any) => fetchApi<any>(`/proposals/${draftId}`, { method: 'PUT', body: JSON.stringify(data) }),
  exportProposal: (draftId: number, format: string) => fetchApi<any>(`/proposals/${draftId}/export?format=${format}`),

  // Budget
  getBudget: (projectId: number = 1) => fetchApi<any>(`/budget?project_id=${projectId}`),
  addBudgetItem: (item: any) => fetchApi<any>('/budget/items', { method: 'POST', body: JSON.stringify(item) }),
  deleteBudgetItem: (id: number) => fetchApi<any>(`/budget/items/${id}`, { method: 'DELETE' }),
  calculateBudget: (projectId: number, maxLimit?: number) => fetchApi<any>('/budget/calculate', { method: 'POST', body: JSON.stringify({ project_id: projectId, max_limit: maxLimit }) }),

  // Compliance
  runComplianceCheck: (projectId: number) => fetchApi<any>('/compliance/check', { method: 'POST', body: JSON.stringify({ project_id: projectId }) }),

  // Submission
  getSubmissionPreview: (projectId: number) => fetchApi<any>(`/submission/${projectId}`),
  approveAndSubmit: (projectId: number, facultyApproved: boolean, approvedBy: string) =>
    fetchApi<any>('/submission/approve', { method: 'POST', body: JSON.stringify({ project_id: projectId, faculty_approved: facultyApproved, approved_by: approvedBy }) }),

  // Agents
  getAgents: () => fetchApi<any[]>('/agents'),
  runAgent: (agentId: string, projectId: number, parameters: any = {}) =>
    fetchApi<any>('/agents/run', { method: 'POST', body: JSON.stringify({ agent_id: agentId, project_id: projectId, parameters }) }),
  getAgentLogs: () => fetchApi<any[]>('/agents/logs'),

  // Workflow Graph
  getWorkflowGraph: () => fetchApi<any>('/workflows/graph'),
  runWorkflowGraph: (topic: string, domain: string, budget: number, facultyApproved: boolean) =>
    fetchApi<any>('/workflows/graph/run', { method: 'POST', body: JSON.stringify({ topic, domain, budget, faculty_approved: facultyApproved }) }),

  // 14 Labs
  getLabs: () => fetchApi<any[]>('/labs'),
  getLabDetail: (week: number) => fetchApi<any>(`/labs/${week}`),
  runLab: (week: number) => fetchApi<any>(`/labs/${week}/run`, { method: 'POST' }),
  testLab: (week: number) => fetchApi<any>(`/labs/${week}/test`, { method: 'POST' }),
  getLabReport: (week: number) => fetchApi<any>(`/labs/${week}/report`)
};
