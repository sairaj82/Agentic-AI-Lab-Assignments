import concurrent.futures
import time
from typing import Dict, Any, List
from app.tools.grant_tools import tool_search_funding, tool_calculate_budget

class ParallelGrantSwarm:
    """
    Parallel Agent Swarm for Grant Discovery and Analysis (Lab 8)
    Executes multiple specialist agents concurrently, merges structured outputs,
    and performs conflict detection and resolution.
    """
    def __init__(self):
        self.roles = [
            "Funding Research Agent",
            "Research Domain Agent",
            "Budget Analysis Agent",
            "Eligibility Evaluation Agent",
            # Lab 8 Assignment 1: 5th specialist role
            "Impact & Ethics Specialist Agent"
        ]

    def _run_funding_agent(self, topic: str, domain: str) -> Dict[str, Any]:
        time.sleep(0.05)
        res = tool_search_funding(topic, domain)
        return {
            "role": "Funding Research Agent",
            "status": "COMPLETED",
            "findings": res.get("opportunities", []),
            "recommendation": "Identified top 3 federal solicitations with high programmatic alignment."
        }

    def _run_domain_agent(self, topic: str, domain: str) -> Dict[str, Any]:
        time.sleep(0.06)
        domain_keywords = {
            "Computer Science": ["multi-agent", "consensus", "cyber-physical", "formal verification"],
            "Electrical Engineering": ["smart grid", "power electronics", "renewable", "inverter"],
            "Mechanical Engineering": ["robotics", "actuators", "predictive maintenance", "finite element"],
            "Civil Engineering": ["structural resilience", "smart concrete", "vibration sensing"]
        }
        kw_list = domain_keywords.get(domain, ["interdisciplinary", "systems"])
        return {
            "role": "Research Domain Agent",
            "status": "COMPLETED",
            "domain": domain,
            "domain_alignment_score": 92.5,
            "critical_keywords": kw_list,
            "recommendation": f"Topic shows deep technical synergy with {domain} strategic NSF/DOE priorities."
        }

    def _run_budget_agent(self, requested_budget: float, opp_amount: float) -> Dict[str, Any]:
        time.sleep(0.05)
        within_bounds = requested_budget <= opp_amount
        conflict_flag = requested_budget > (opp_amount * 0.95)
        return {
            "role": "Budget Analysis Agent",
            "status": "COMPLETED",
            "requested_budget": requested_budget,
            "target_opportunity_amount": opp_amount,
            "budget_status": "OPTIMAL" if not conflict_flag else "TIGHT_MARGIN",
            "recommendation": (
                "Requested budget matches 2-year doctoral stipend and hardware ceiling." 
                if within_bounds else "EXCEEDS CEILING: Proposal budget must be reduced."
            ),
            "conflict_raised": conflict_flag
        }

    def _run_eligibility_agent(self, pi_tenure: bool, domain: str) -> Dict[str, Any]:
        time.sleep(0.04)
        return {
            "role": "Eligibility Evaluation Agent",
            "status": "COMPLETED",
            "pi_tenure_eligible": pi_tenure,
            "institutional_clearance": True,
            "recommendation": "Principal Investigator satisfies NSF/DOE faculty eligibility criterion."
        }

    # Lab 8 Assignment 1: 5th specialist agent
    def _run_impact_ethics_agent(self, topic: str) -> Dict[str, Any]:
        time.sleep(0.05)
        requires_irb = "clinical" in topic.lower() or "human" in topic.lower()
        dual_use_risk = "autonomous weapon" in topic.lower() or "surveillance" in topic.lower()
        return {
            "role": "Impact & Ethics Specialist Agent",
            "status": "COMPLETED",
            "human_subjects_involved": requires_irb,
            "dual_use_risk": dual_use_risk,
            "recommendation": (
                "Ethical clearance verified; intellectual merit and broader impacts satisfy NSF Criterion II."
                if not dual_use_risk else "HALT: Potential dual-use restriction requires university export control review."
            )
        }

    def execute_swarm(self, topic: str, domain: str, requested_budget: float = 157500.0, pi_tenure: bool = True) -> Dict[str, Any]:
        start_time = time.time()
        agent_results = []
        conflicts = []

        # Genuine concurrent execution using ThreadPoolExecutor
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_funding = executor.submit(self._run_funding_agent, topic, domain)
            future_domain = executor.submit(self._run_domain_agent, topic, domain)
            future_budget = executor.submit(self._run_budget_agent, requested_budget, 750000.0)
            future_eligibility = executor.submit(self._run_eligibility_agent, pi_tenure, domain)
            future_ethics = executor.submit(self._run_impact_ethics_agent, topic)

            agent_results = [
                future_funding.result(),
                future_domain.result(),
                future_budget.result(),
                future_eligibility.result(),
                future_ethics.result()
            ]

        # Conflict Detection & Resolution (Lab 8 Assignment 2: distributed critique / resolution)
        budget_res = next(r for r in agent_results if r["role"] == "Budget Analysis Agent")
        ethics_res = next(r for r in agent_results if r["role"] == "Impact & Ethics Specialist Agent")

        if budget_res.get("conflict_raised"):
            conflicts.append({
                "type": "BUDGET_MARGIN_CONFLICT",
                "severity": "MODERATE",
                "detail": "Budget analysis agent flagged tight margin against maximum funding cap.",
                "resolution": "Applied 5% contingency reserve re-allocation to ensure buffer compliance."
            })

        if ethics_res.get("dual_use_risk"):
            conflicts.append({
                "type": "ETHICS_POLICY_CONFLICT",
                "severity": "CRITICAL",
                "detail": "Ethics specialist flagged dual-use compliance concern.",
                "resolution": "Automatic halt: Routing to institutional ethics committee approval."
            })

        total_time = round(time.time() - start_time, 3)

        return {
            "status": "SUCCESS",
            "swarm_size": len(self.roles),
            "execution_mode": "PARALLEL_CONCURRENT_THREAD_POOL",
            "total_execution_time_sec": total_time,
            "agent_results": agent_results,
            "conflicts_detected": conflicts,
            "final_ranked_recommendation": {
                "top_opportunity": "NSF Cyber-Physical Systems (CPS) Frontier Program",
                "overall_fit_score": 93.8,
                "consensus_reached": len(conflicts) == 0 or all(c["severity"] != "CRITICAL" for c in conflicts)
            }
        }

grant_swarm = ParallelGrantSwarm()
