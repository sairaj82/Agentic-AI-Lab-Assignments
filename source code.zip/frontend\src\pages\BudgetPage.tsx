import React, { useState, useEffect } from 'react';
import { DollarSign, Plus, Trash2, Calculator, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { api } from '../services/api';

const CATEGORIES = ['Personnel', 'Equipment', 'Travel', 'Consumables', 'Indirect'];

export const BudgetPage: React.FC = () => {
  const [items, setItems] = useState<any[]>([]);
  const [totalBudget, setTotalBudget] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);
  const [calcResult, setCalcResult] = useState<any>(null);
  const [maxLimit, setMaxLimit] = useState<number>(500000);

  // New item form
  const [newItem, setNewItem] = useState({
    category: 'Personnel',
    description: '',
    quantity: 1,
    unit_cost: 25000,
    justification: ''
  });

  const loadBudget = async () => {
    try {
      const data = await api.getBudget(1);
      setItems(data.items || []);
      setTotalBudget(data.total_budget || 0);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    loadBudget();
  }, []);

  const handleAddItem = async () => {
    if (!newItem.description.trim()) return;
    try {
      await api.addBudgetItem({
        ...newItem,
        project_id: 1,
        total_cost: newItem.quantity * newItem.unit_cost
      });
      setNewItem({ category: 'Personnel', description: '', quantity: 1, unit_cost: 25000, justification: '' });
      await loadBudget();
    } catch (e: any) {
      alert(`Failed to add item: ${e.message}`);
    }
  };

  const handleDeleteItem = async (id: number) => {
    try {
      await api.deleteBudgetItem(id);
      await loadBudget();
    } catch (e: any) {
      alert(`Failed to delete item: ${e.message}`);
    }
  };

  const handleRunCalculation = async () => {
    setCalculating(true);
    try {
      const res = await api.calculateBudget(1, maxLimit);
      setCalcResult(res);
    } catch (e: any) {
      alert(`Calculation error: ${e.message}`);
    }
    setCalculating(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Budget Planner</h2>
          <p className="text-slate-500 text-sm mt-1">
            Build line-item grant budgets, calculate overhead, and generate fiscal justifications
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-blue-50 border border-blue-200">
            <span className="text-xs text-blue-600 font-semibold block">Total Direct Budget</span>
            <span className="text-xl font-extrabold text-blue-900 font-mono">${totalBudget.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Add Item Form */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
          <Plus className="w-4 h-4 text-blue-600" /> Add Line Item
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div>
            <label className="text-xs font-semibold text-slate-600">Category</label>
            <select
              value={newItem.category}
              onChange={e => setNewItem({ ...newItem, category: e.target.value })}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
              {CATEGORIES.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="text-xs font-semibold text-slate-600">Description</label>
            <input
              type="text"
              placeholder="e.g. Graduate Research Assistant (2 Semesters)"
              value={newItem.description}
              onChange={e => setNewItem({ ...newItem, description: e.target.value })}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-600">Quantity</label>
            <input
              type="number"
              min={1}
              value={newItem.quantity}
              onChange={e => setNewItem({ ...newItem, quantity: Number(e.target.value) })}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-600">Unit Cost ($)</label>
            <input
              type="number"
              value={newItem.unit_cost}
              onChange={e => setNewItem({ ...newItem, unit_cost: Number(e.target.value) })}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-600">Budget Justification Narrative</label>
          <input
            type="text"
            placeholder="Justify necessity according to solicitation guidelines..."
            value={newItem.justification}
            onChange={e => setNewItem({ ...newItem, justification: e.target.value })}
            className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <button
          onClick={handleAddItem}
          className="px-5 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition shadow-sm"
        >
          Add to Budget Plan
        </button>
      </div>

      {/* Items Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 text-left text-xs text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <th className="px-5 py-3">Category</th>
              <th className="px-5 py-3">Description & Justification</th>
              <th className="px-5 py-3">Qty</th>
              <th className="px-5 py-3">Unit Cost</th>
              <th className="px-5 py-3">Total Cost</th>
              <th className="px-5 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-8 text-slate-400 italic">
                  No line items found. Add items using the form above.
                </td>
              </tr>
            ) : (
              items.map((it: any) => (
                <tr key={it.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                  <td className="px-5 py-3.5">
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold">
                      {it.category}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <p className="font-semibold text-slate-800">{it.description}</p>
                    {it.justification && (
                      <p className="text-xs text-slate-400 italic mt-0.5">{it.justification}</p>
                    )}
                  </td>
                  <td className="px-5 py-3.5 font-mono text-slate-700">{it.quantity}</td>
                  <td className="px-5 py-3.5 font-mono text-slate-700">${it.unit_cost.toLocaleString()}</td>
                  <td className="px-5 py-3.5 font-bold font-mono text-slate-900">${it.total_cost.toLocaleString()}</td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => handleDeleteItem(it.id)}
                      className="p-1 text-slate-400 hover:text-red-600 transition"
                      title="Delete Item"
                    >
                      <Trash2 className="w-4 h-4 inline" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Fiscal Agent Audit & Calculation */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
              <Calculator className="w-4 h-4 text-blue-600" /> Budget Planning Agent Execution
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Automated indirect cost (overhead), fringe, and threshold calculation</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-600">Funding Cap ($):</label>
              <input
                type="number"
                value={maxLimit}
                onChange={e => setMaxLimit(Number(e.target.value))}
                className="w-32 px-3 py-1.5 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>
            <button
              onClick={handleRunCalculation}
              disabled={calculating}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 disabled:opacity-50 transition shadow-sm"
            >
              {calculating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Calculator className="w-3.5 h-3.5" />}
              Run Fiscal Audit
            </button>
          </div>
        </div>

        {calcResult && (
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Direct Costs</span>
                <p className="text-base font-extrabold text-slate-900 font-mono mt-1">
                  ${(calcResult.direct_costs || calcResult.total_cost || totalBudget).toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Indirect (F&A)</span>
                <p className="text-base font-extrabold text-slate-900 font-mono mt-1">
                  ${(calcResult.indirect_costs || Math.round(totalBudget * 0.28)).toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Total Proposed</span>
                <p className="text-base font-extrabold text-blue-900 font-mono mt-1">
                  ${(calcResult.total_cost_with_indirect || Math.round(totalBudget * 1.28)).toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Cap Compliance</span>
                <p className={`text-sm font-extrabold mt-1 flex items-center gap-1 ${
                  calcResult.within_limit !== false ? 'text-emerald-700' : 'text-red-700'
                }`}>
                  {calcResult.within_limit !== false ? (
                    <><CheckCircle2 className="w-4 h-4 text-emerald-600" /> WITHIN CAP</>
                  ) : (
                    <><AlertTriangle className="w-4 h-4 text-red-600" /> EXCEEDS CAP</>
                  )}
                </p>
              </div>
            </div>

            {calcResult.justification && (
              <div className="bg-white p-4 rounded-lg border border-slate-200">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Automated Budget Justification Narrative</h4>
                <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap font-sans">
                  {typeof calcResult.justification === 'string' ? calcResult.justification : JSON.stringify(calcResult.justification, null, 2)}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
