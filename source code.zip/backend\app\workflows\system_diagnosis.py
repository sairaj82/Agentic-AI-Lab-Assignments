import datetime
from typing import Dict, Any, List

class SystemDiagnosisAgent:
    """
    Cloud Operations / System Diagnosis Agent for Grant Operations (Lab 10).
    Workflow: Observe -> Reason -> Diagnose -> Classify Severity -> Remediate / Escalate.
    """
    def __init__(self):
        self.incident_history: List[Dict[str, Any]] = []

    def diagnose_incident(self, event_type: str, raw_logs: str) -> Dict[str, Any]:
        """
        Diagnose system event, classify severity (INFO, WARNING, ALARM),
        and determine if safe auto-remediation applies or requires human approval.
        """
        logs_lower = raw_logs.lower()
        now_ts = datetime.datetime.now().isoformat()

        # Scenario 1: PDF Extraction / Parsing Failure
        if "pdf" in event_type.lower() or "pdf" in logs_lower:
            severity = "WARNING"
            root_cause = "Corrupt PDF stream or unsupported font encoding in uploaded paper."
            remediation_plan = "Switch parser to fallback OCR / pypdf text extractor and notify user."
            # Lab 10 Assignment 2: Safe auto-remediation for WARNING
            auto_executable = True
            action_taken = "Auto-remediation executed: invoked fallback ASCII extractor on buffer."

        # Scenario 2 (Lab 10 Assignment 1): Database Connection Pool Exhaustion / Lock
        elif "sqlite" in logs_lower or "database" in event_type.lower() or "locked" in logs_lower or "pool" in logs_lower:
            severity = "ALARM"
            root_cause = "SQLite database lock contention caused by concurrent agent writes exceeding thread pool limits."
            remediation_plan = "Drain active transaction pool, recycle connections, and rebuild transient indexes."
            # Mandatory human approval for ALARM
            auto_executable = False
            action_taken = "Blocked: High-risk action requires human database administrator authorization."

        # Scenario 3: Funding API Timeout
        elif "timeout" in logs_lower or "api" in logs_lower:
            severity = "WARNING"
            root_cause = "Federal grant portal API latency exceeded 5000ms threshold."
            remediation_plan = "Enable stale-while-revalidate local grant cache."
            auto_executable = True
            action_taken = "Auto-remediation executed: switched to cached local opportunity catalog."

        else:
            severity = "INFO"
            root_cause = "Routine telemetry spike under normal load."
            remediation_plan = "Log event and continue background monitoring."
            auto_executable = True
            action_taken = "Logged to telemetry stream."

        diagnosis_record = {
            "incident_id": f"INC-{len(self.incident_history) + 101}",
            "timestamp": now_ts,
            "event_type": event_type,
            "severity": severity,
            "root_cause": root_cause,
            "remediation_plan": remediation_plan,
            "safe_auto_executable": auto_executable,
            "action_taken": action_taken,
            "human_approval_required": not auto_executable
        }
        self.incident_history.append(diagnosis_record)
        return diagnosis_record

system_diagnosis_agent = SystemDiagnosisAgent()
