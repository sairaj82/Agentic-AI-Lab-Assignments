import json
from typing import Dict, Any, List
from app.rag.deep_research import DeepResearchEngine, SOURCE_TIERS

def run_lab_week09() -> Dict[str, Any]:
    engine = DeepResearchEngine()

    # Ingest diverse source materials with varying quality tiers (Lab 9 Assignment 2)
    # Source 1: High Tier 1 Q1 Journal
    engine.ingest_text(
        source_title="Nature Machine Intelligence (2025)",
        raw_text="Formal state contracts guarantee bounded execution latency in multi-agent networks, preventing synchronization collapse.",
        tier="TIER_1_Q1_JOURNAL"
    )

    # Source 2: Tier 2 Top Conference
    engine.ingest_text(
        source_title="IEEE Transactions on Cyber-Physical Systems (2024)",
        raw_text="Empirical evaluations across 48 physical nodes confirm that decentralized consensus reduces communication bottleneck by 31%.",
        tier="TIER_2_TOP_CONFERENCE"
    )

    # Source 3 (Lab 9 Assignment 1: Contradicting Source):
    # Directly contradicts Source 2 by claiming throughput degradation
    engine.ingest_text(
        source_title="ACM Systems Letters (2024)",
        raw_text="Under bursty packet corruption, decentralized consensus protocols suffer severe throughput collapse, causing message delays to degrade quadratically.",
        tier="TIER_2_TOP_CONFERENCE"
    )

    # Source 4: Tier 4 Preprint
    engine.ingest_text(
        source_title="arXiv Preprint 2408.0199 (2024)",
        raw_text="Unverified preliminary simulations suggest multi-agent swarms achieve 100x efficiency over central coordinators.",
        tier="TIER_4_PREPRINT"
    )

    # Execute semantic retrieval with source-quality weighting
    topic_query = "decentralized consensus multi-agent latency bottleneck"
    retrieved = engine.retrieve_evidence(topic_query, top_k=4)

    # Synthesize findings with contradiction detection and citation provenance
    synthesis_report = engine.synthesize_research(topic_query, retrieved)

    # Verification of Assignment 2: Verify Tier 1 journal has higher quality weight than Preprint
    t1_weight = SOURCE_TIERS["TIER_1_Q1_JOURNAL"]["weight"]
    t4_weight = SOURCE_TIERS["TIER_4_PREPRINT"]["weight"]

    return {
        "week": 9,
        "title": "Lab 9: Deep Research Agent -- RAG Evidence Synthesis, Contradiction Detection & Quality Weighting",
        "total_chunks_indexed": len(engine.chunks),
        "source_tiers_defined": SOURCE_TIERS,
        "retrieved_evidence": retrieved,
        "assignment_1_contradicting_evidence": {
            "contradiction_detected": synthesis_report["contradiction_detected"],
            "contradiction_analysis": synthesis_report["contradiction_note"],
            "competing_sources": [e["source"] for e in retrieved if "consensus" in e["text"].lower()]
        },
        "assignment_2_source_quality_weighting": {
            "tier_1_weight": t1_weight,
            "tier_4_weight": t4_weight,
            "weighting_ratio": round(t1_weight / t4_weight, 2),
            "tier_breakdown": synthesis_report["source_tier_breakdown"],
            "passed": t1_weight > t4_weight
        },
        "executive_synthesis": synthesis_report["synthesis"],
        "citations_verified": synthesis_report["citations"],
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week09()
    print(json.dumps(result, indent=2))
