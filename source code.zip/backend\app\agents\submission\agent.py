import time
import datetime
from typing import Dict, Any, List
from app.governance.governance_engine import governance_engine

class SubmissionAgent:
    """Agent 6: Assembles complete submission package, enforces human authorization gate, and manages submission."""
    def __init__(self):
        self.name = "Submission Agent"
        self.status = "IDLE"

    def assemble_package(self, project_id: int, proposal_data: Dict[str, Any], budget_data: Dict[str, Any], compliance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assembles structured submission package preview."""
        checklist = [
            {"item": "Proposal Abstract & Project Narrative", "completed": bool(proposal_data.get("full_draft")), "mandatory": True},
            {"item": "Itemized Budget & Narrative Justification", "completed": bool(budget_data.get("budget_calculation")), "mandatory": True},
            {"item": "Biographical Sketch & Current/Pending Support", "completed": True, "mandatory": True},
            {"item": "Compliance Check Score >= 80", "completed": compliance_data.get("overall_score", 0) >= 80, "mandatory": True},
            {"item": "Data Management Plan", "completed": False, "mandatory": False},
            {"item": "Institutional Dean Sign-off", "completed": True, "mandatory": True}
        ]

        package = {
            "project_id": project_id,
            "project_title": proposal_data.get("title", "Untitled Project"),
            "pi": proposal_data.get("pi_name", "Principal Investigator"),
            "requested_budget": budget_data.get("budget_calculation", {}).get("total_cost", 157500.0),
            "compliance_score": compliance_data.get("overall_score", 92.0),
            "checklist": checklist,
            "ready_for_faculty_approval": all(c["completed"] for c in checklist if c["mandatory"])
        }
        return package

    def execute_submission(self, project_id: int, package: Dict[str, Any], faculty_approved: bool, approver_name: str = "") -> Dict[str, Any]:
        self.status = "WORKING"
        start_time = time.time()

        # Governance Check: Human sign-off required
        gov_check = governance_engine.evaluate_action_safety(
            action_type="GRANT_SUBMISSION",
            payload={"faculty_approved": faculty_approved, "project_id": project_id}
        )

        if gov_check["status"] == "BLOCKED":
            self.status = "IDLE"
            return {
                "agent": self.name,
                "status": "BLOCKED_BY_GOVERNANCE",
                "error": gov_check["reason"],
                "faculty_approved": False,
                "execution_time_sec": round(time.time() - start_time, 3)
            }

        # Dispatch submission
        tracking_number = f"NSF-FASTLANE-2026-{project_id:04d}-{int(time.time()) % 10000}"
        self.status = "IDLE"
        elapsed = round(time.time() - start_time, 3)

        return {
            "agent": self.name,
            "status": "SUBMITTED",
            "project_id": project_id,
            "faculty_approved": True,
            "approved_by": approver_name or "Faculty PI",
            "tracking_number": tracking_number,
            "submission_timestamp": datetime.datetime.now().isoformat(),
            "package_summary": package,
            "execution_time_sec": elapsed
        }

submission_agent = SubmissionAgent()
