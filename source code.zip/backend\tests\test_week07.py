import pytest
from labs.week07.lab import run_lab_week07

def test_week07_execution():
    result = run_lab_week07()
    assert result is not None
    assert result.get('completed') is True
    assert result.get('week') == 7

def test_week07_assignments():
    result = run_lab_week07()
    keys = list(result.keys())
    assign_keys = [k for k in keys if 'assignment' in k]
    assert len(assign_keys) >= 2, f'Week 7 must contain at least 2 assignment outputs'
