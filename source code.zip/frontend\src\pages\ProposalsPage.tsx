import React, { useState, useEffect } from 'react';
import { PenTool, Download, Save, RefreshCw, Loader2, CheckCircle2, FileText, ChevronRight } from 'lucide-react';
import { api } from '../services/api';

export const ProposalsPage: React.FC = () => {
  const [proposals, setProposals] = useState<any[]>([]);
  const [activeDraft, setActiveDraft] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Generation form
  const [topic, setTopic] = useState('Verifiable Autonomous Systems for Critical Infrastructure');
  const [domain, setDomain] = useState('Computer Science');
  const [piName, setPiName] = useState('Dr. Aris Thorne');

  const loadProposals = async () => {
    try {
      const data = await api.getProposals();
      setProposals(data);
      if (data.length > 0 && !activeDraft) {
        setActiveDraft(data[0]);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    loadProposals();
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await api.generateProposal(1, topic, domain, piName);
      if (res.draft) {
        setActiveDraft(res.draft);
        await loadProposals();
      }
    } catch (e: any) {
      alert(`Generation failed: ${e.message}`);
    }
    setGenerating(false);
  };

  const handleSaveDraft = async () => {
    if (!activeDraft) return;
    setSaving(true);
    try {
      await api.updateProposal(activeDraft.id, {
        title: activeDraft.title,
        abstract: activeDraft.abstract,
        methodology: activeDraft.methodology,
        objectives: activeDraft.objectives,
        expected_outcomes: activeDraft.expected_outcomes,
        full_draft: activeDraft.full_draft
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e: any) {
      alert(`Save failed: ${e.message}`);
    }
    setSaving(false);
  };

  const handleExport = async (format: string) => {
    if (!activeDraft) return;
    try {
      const res = await api.exportProposal(activeDraft.id, format);
      const blob = new Blob(
        [format === 'json' ? JSON.stringify(res, null, 2) : res.content || activeDraft.full_draft],
        { type: format === 'json' ? 'application/json' : 'text/markdown' }
      );
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Proposal_v${activeDraft.version}_${activeDraft.title.replace(/\s+/g, '_')}.${format === 'json' ? 'json' : 'md'}`;
      a.click();
    } catch (e: any) {
      alert(`Export failed: ${e.message}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Proposal Workspace</h2>
          <p className="text-slate-500 text-sm mt-1">
            Author, structure, version, and export complete NSF/DoD-compliant research proposals
          </p>
        </div>
        {activeDraft && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleExport('markdown')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              <Download className="w-3.5 h-3.5" /> Export Markdown
            </button>
            <button
              onClick={() => handleExport('json')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              <Download className="w-3.5 h-3.5" /> Export JSON
            </button>
            <button
              onClick={handleSaveDraft}
              disabled={saving}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              Save Changes
            </button>
          </div>
        )}
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Draft version successfully updated and saved to SQLite database.
        </div>
      )}

      {/* Generation Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
            <PenTool className="w-4 h-4 text-blue-600" /> Proposal Drafting Agent Generation
          </h3>
          <span className="text-xs text-slate-400">Structured generation with NSF section compliance</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input
            type="text"
            placeholder="Research Title / Focus"
            value={topic}
            onChange={e => setTopic(e.target.value)}
            className="md:col-span-2 px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <select
            value={domain}
            onChange={e => setDomain(e.target.value)}
            className="px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            {['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering'].map(d => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </div>
        <button
          onClick={handleGenerate}
          disabled={generating || !topic.trim()}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition shadow-sm"
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Synthesizing Proposal Sections...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4" /> Generate New Structured Proposal Draft
            </>
          )}
        </button>
      </div>

      {/* Editor & Version Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Version List */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm h-fit space-y-3">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Version History ({proposals.length})</h4>
          {proposals.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No drafts generated yet.</p>
          ) : (
            <div className="space-y-2">
              {proposals.map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => setActiveDraft(p)}
                  className={`w-full text-left p-3 rounded-lg border text-xs transition ${
                    activeDraft?.id === p.id
                      ? 'border-blue-600 bg-blue-50/50 text-blue-900 font-semibold shadow-sm'
                      : 'border-slate-100 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">v{p.version}.0</span>
                    <span className="text-[10px] text-slate-400">{p.created_at ? p.created_at.slice(0, 10) : 'Recent'}</span>
                  </div>
                  <p className="truncate mt-1 text-slate-700">{p.title}</p>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Structured Editor */}
        <div className="lg:col-span-3 space-y-5">
          {activeDraft ? (
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-5">
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Proposal Title</label>
                <input
                  type="text"
                  value={activeDraft.title || ''}
                  onChange={e => setActiveDraft({ ...activeDraft, title: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-lg border border-slate-200 text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Executive Abstract</label>
                <textarea
                  rows={4}
                  value={activeDraft.abstract || ''}
                  onChange={e => setActiveDraft({ ...activeDraft, abstract: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Research Methodology</label>
                <textarea
                  rows={6}
                  value={activeDraft.methodology || ''}
                  onChange={e => setActiveDraft({ ...activeDraft, methodology: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Full Draft Text / Markdown</label>
                <textarea
                  rows={8}
                  value={activeDraft.full_draft || ''}
                  onChange={e => setActiveDraft({ ...activeDraft, full_draft: e.target.value })}
                  className="w-full mt-1.5 px-3.5 py-2 rounded-lg border border-slate-200 text-xs text-slate-800 font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
              <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-700">No Draft Selected</h3>
              <p className="text-xs text-slate-400 mt-1">Generate a proposal draft using the bar above or select an existing version.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
