import json
from typing import Dict, Any, List
from app.governance.governance_engine import GovernanceEngine

def run_lab_week12() -> Dict[str, Any]:
    gov = GovernanceEngine(cost_threshold=100000.0, re_eval_threshold_n=3)

    # 1. Prohibited High-Risk Action Test: Auto-submitting grant without faculty PI approval
    unauthorized_sub_res = gov.evaluate_action_safety(
        action_type="GRANT_SUBMISSION",
        payload={"faculty_approved": False, "project_id": 1}
    )

    # 2. Approved Action Test: Grant submission with human PI approval
    authorized_sub_res = gov.evaluate_action_safety(
        action_type="GRANT_SUBMISSION",
        payload={"faculty_approved": True, "project_id": 1}
    )

    # 3. Assignment 1: Cost-Category & Budget Threshold Control
    # Case A: Request under $100k -> Cleared
    small_budget_action = gov.evaluate_action_safety(
        action_type="EQUIPMENT_PURCHASE",
        payload={"total_cost": 45000.0, "item": "GPU Cluster"}
    )
    # Case B: Request over $100k -> Requires Dean/CFO Fiscal Approval
    large_budget_action = gov.evaluate_action_safety(
        action_type="EQUIPMENT_PURCHASE",
        payload={"total_cost": 250000.0, "item": "Cleanroom Laser Spectrometer"}
    )

    # 4. Assignment 2: Mandatory Re-Evaluation After N Proposals
    eval_triggers = []
    for i in range(3):
        rec = gov.record_proposal_completion()
        eval_triggers.append(rec)

    # 5. Quantitative Evaluation Suite
    evaluation_suite = gov.run_quantitative_evaluation()

    return {
        "week": 12,
        "title": "Lab 12: Safety, Evaluation, and Governance -- Least Privilege, Approval Gates & Quantitative Metrics",
        "governance_tests": {
            "prohibited_auto_submission": unauthorized_sub_res,
            "authorized_submission": authorized_sub_res,
            "policy_enforced": unauthorized_sub_res["status"] == "BLOCKED" and authorized_sub_res["status"] == "CLEARED"
        },
        "assignment_1_cost_threshold_control": {
            "threshold_limit": gov.cost_threshold,
            "small_action_result": small_budget_action,
            "large_action_result": large_budget_action,
            "control_passed": small_budget_action["status"] == "CLEARED" and large_budget_action["status"] == "APPROVAL_REQUIRED"
        },
        "assignment_2_mandatory_reevaluation": {
            "proposals_simulated": len(eval_triggers),
            "re_eval_threshold": gov.re_eval_threshold_n,
            "triggered_on_proposal_3": eval_triggers[-1]["re_evaluation_triggered"],
            "reevaluation_report": eval_triggers[-1]["evaluation_report"],
            "passed": eval_triggers[-1]["re_evaluation_triggered"] is True
        },
        "quantitative_evaluation_suite": evaluation_suite,
        "governance_audit_log": gov.audit_log,
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week12()
    print(json.dumps(result, indent=2))
