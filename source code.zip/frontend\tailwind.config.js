/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#070F1E',
          900: '#0B192C',
          850: '#0E223D',
          800: '#15305B',
          700: '#1E40AF',
          600: '#2563EB',
          500: '#3B82F6',
          100: '#E0E7FF',
          50: '#EEF2FF',
        }
      }
    },
  },
  plugins: [],
}
