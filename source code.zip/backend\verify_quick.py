import sys, time
sys.path.insert(0, 'backend')

print("=== 1. CHECK DATABASE & APP STARTUP ===")
from app.database.session import SessionLocal, engine
from app.database.models import Base, Faculty, GrantOpportunity, ResearchProject, ProposalDraft, BudgetItem, ComplianceCheck
Base.metadata.create_all(bind=engine)
db = SessionLocal()
f_count = db.query(Faculty).count()
opp_count = db.query(GrantOpportunity).count()
print(f"DB Connection: OK | Faculty records: {f_count} | Opportunities: {opp_count}")
db.close()

print("\n=== 2. CHECK 6 PRIMARY AGENTS ===")
from app.agents.funding_discovery.agent import funding_agent
from app.agents.literature_review.agent import literature_agent
from app.agents.proposal_drafting.agent import proposal_agent
from app.agents.budget_planning.agent import budget_agent
from app.agents.compliance_checking.agent import compliance_agent
from app.agents.submission.agent import submission_agent

t0 = time.time()
r1 = funding_agent.execute("Autonomous Multi-Agent Networks", "Computer Science")
print(f"1. Funding Discovery Agent: OK (Ranked: {len(r1.get('ranked_opportunities', []))})")

r2 = literature_agent.execute("Multi-Agent Systems")
print(f"2. Literature Review Agent: OK (Gaps: {len(r2.get('identified_gaps', []))})")

r3 = proposal_agent.execute("Autonomous Multi-Agent Networks", "Computer Science")
print(f"3. Proposal Drafting Agent: OK (Title: {r3.get('title')[:35]}...)")

r4 = budget_agent.execute(project_id=1)
print(f"4. Budget Planning Agent: OK (Total: ${r4.get('total_budget', 0):,.2f})")

r5 = compliance_agent.execute(1, r3, r4)
print(f"5. Compliance Checking Agent: OK (Score: {r5.get('overall_score')}/100, Status: {r5.get('overall_compliance_status')})")

r6 = submission_agent.assemble_package(1, r3, r4, r5)
print(f"6. Submission Agent: OK (Package ready: {r6.get('status')})")
print(f"All 6 Agents Verified in: {round(time.time() - t0, 2)}s")

print("\n=== 3. CHECK 4 OFFICIAL EXPECTED OUTPUTS ===")
from fastapi.testclient import TestClient
from main import app
client = TestClient(app)

res = client.get("/api/dashboard/expected-outputs")
assert res.status_code == 200, res.text
out = res.json()
print("Output 1 (Ranked Funding):", out['output_1_ranked_funding']['card_title'], "| Count:", len(out['output_1_ranked_funding']['opportunities']))
print("Output 2 (Structured Proposal):", out['output_2_structured_proposal']['card_title'], "| Sections:", len(out['output_2_structured_proposal']['proposal']))
print("Output 3 (Budget Plan):", out['output_3_budget_plan']['card_title'], "| Total: $" + str(out['output_3_budget_plan']['budget']['total_budget']))
print("Output 4 (Compliance Report):", out['output_4_compliance_report']['card_title'], "| Status:", out['output_4_compliance_report']['compliance']['overall_compliance_status'])

print("\n=== 4. CHECK 14 WEEKLY LAB EXECUTION HANDLERS ===")
for w in range(1, 15):
    mod = __import__(f"labs.week{w:02d}.lab", fromlist=[f"run_lab_week{w:02d}"])
    runner = getattr(mod, f"run_lab_week{w:02d}")
    res_lab = runner()
    assert res_lab.get("week") == w
    print(f"Week {w:02d} Handler: OK -> {res_lab.get('title', '')[:45]}")

print("\nALL VERIFICATIONS PASSED!")
