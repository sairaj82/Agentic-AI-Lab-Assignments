import time
from typing import Dict, Any, List
from app.rag.deep_research import research_engine
from app.skills.grant_skills import SKILL_REGISTRY

class LiteratureReviewAgent:
    """Agent 2: Synthesizes scientific literature, extracts evidence, and isolates research gaps."""
    def __init__(self):
        self.name = "Literature Review Agent"
        self.status = "IDLE"

    def execute(self, topic: str, user_uploaded_text: str = "") -> Dict[str, Any]:
        self.status = "WORKING"
        start_time = time.time()

        if user_uploaded_text.strip():
            research_engine.ingest_text(
                source_title="Faculty Uploaded Research Dossier",
                raw_text=user_uploaded_text,
                tier="TIER_2_TOP_CONFERENCE"
            )

        # 1. Retrieve evidence
        retrieved = research_engine.retrieve_evidence(topic, top_k=4)

        # 2. Synthesize research
        synth_out = research_engine.synthesize_research(topic, retrieved)

        # 3. Identify research gaps
        gap_skill = SKILL_REGISTRY["research_gap_identification"]
        gaps_out = gap_skill.execute({"topic": topic, "literature": synth_out["synthesis"]})

        self.status = "IDLE"
        elapsed = round(time.time() - start_time, 3)

        return {
            "agent": self.name,
            "status": "SUCCESS",
            "topic": topic,
            "evidence_sources": synth_out["citations"],
            "retrieved_evidence": retrieved,
            "synthesis": synth_out["synthesis"],
            "contradiction_detected": synth_out["contradiction_detected"],
            "contradiction_note": synth_out["contradiction_note"],
            "identified_gaps": gaps_out["identified_gaps"],
            "novelty_statement": gaps_out["novelty_statement"],
            "execution_time_sec": elapsed
        }

literature_agent = LiteratureReviewAgent()
