import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { TrendingUp, Users, FileText, DollarSign, ShieldCheck, Send, Bot, Clock, Activity } from 'lucide-react';
import { api } from '../services/api';

const COLORS = ['#2563EB', '#7C3AED', '#059669', '#D97706', '#DC2626', '#6366F1'];

export const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getDashboardStats().then(data => { setStats(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-96"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  const s = stats?.stats || {};

  const statCards = [
    { label: 'Funding Opportunities', value: s.total_funding_opportunities ?? 0, icon: TrendingUp, color: 'bg-blue-500', textColor: 'text-blue-600' },
    { label: 'Active Projects', value: s.active_research_projects ?? 0, icon: Users, color: 'bg-violet-500', textColor: 'text-violet-600' },
    { label: 'Proposals In Progress', value: s.proposals_in_progress ?? 0, icon: FileText, color: 'bg-emerald-500', textColor: 'text-emerald-600' },
    { label: 'Approved Submissions', value: s.approved_proposals ?? 0, icon: Send, color: 'bg-amber-500', textColor: 'text-amber-600' },
    { label: 'Pending Compliance', value: s.pending_compliance_checks ?? 0, icon: ShieldCheck, color: 'bg-rose-500', textColor: 'text-rose-600' },
    { label: 'AI Agents Active', value: s.ai_agents_active ?? 6, icon: Bot, color: 'bg-indigo-500', textColor: 'text-indigo-600' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Command Centre</h2>
        <p className="text-slate-500 text-sm mt-1">Autonomous Research Grant Lifecycle Overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{card.label}</p>
                  <p className="text-3xl font-extrabold text-slate-900 mt-2">{card.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl ${card.color} bg-opacity-10 flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${card.textColor}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Domain Analytics Chart */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Funding Distribution by Domain</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={stats?.domain_analytics || []}>
              <XAxis dataKey="domain" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#2563EB" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Budget Allocation Pie */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Budget Allocation by Category</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={stats?.budget_analytics || []} dataKey="allocated" nameKey="category" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {(stats?.budget_analytics || []).map((_: any, i: number) => (
                  <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
        <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2"><Activity className="w-4 h-4 text-blue-500" /> Recent Agent Activity</h3>
        {(stats?.recent_activities || []).length === 0 ? (
          <p className="text-sm text-slate-400 italic">No recent agent activity. Run agents or labs to generate activity logs.</p>
        ) : (
          <div className="space-y-3">
            {(stats?.recent_activities || []).map((act: any, i: number) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                <div className="flex items-center gap-3">
                  <Bot className="w-4 h-4 text-blue-500" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">{act.agent}</p>
                    <p className="text-xs text-slate-400">{act.task}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${act.status === 'SUCCESS' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{act.status}</span>
                  <span className="text-xs text-slate-400 flex items-center gap-1"><Clock className="w-3 h-3" />{act.time}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
