import json
from typing import Dict, Any, List
from app.skills.grant_skills import SKILL_REGISTRY

def run_lab_week03() -> Dict[str, Any]:
    # Skill 1: Research Summarization
    sample_paper = (
        "In this study, we propose a decentralized verification protocol for cyber-physical agent swarms. "
        "Evaluating our method on a 32-node physical testbed demonstrated a 34% reduction in consensus latency "
        "and zero synchronization deadlocks under 15% random packet drops."
    )
    res_summary = SKILL_REGISTRY["research_summarization"].execute({"text": sample_paper})

    # Skill 2: Funding Opportunity Evaluation
    res_funding_eval = SKILL_REGISTRY["funding_evaluation"].execute({
        "topic": "decentralized cyber-physical multi-agent verification",
        "opportunity": {
            "id": 1,
            "title": "NSF Cyber-Physical Systems (CPS) Frontier Program",
            "description": "Supports research in intelligent cyber-physical systems, multi-agent control, and verification.",
            "eligibility": "Tenure-track PI required; Indirect cost cap 26%."
        }
    })

    # Skill 3: Research Gap Identification
    res_gaps = SKILL_REGISTRY["research_gap_identification"].execute({
        "topic": "Multi-Agent Consensus under Adversarial Delay",
        "literature": sample_paper
    })

    # Skill 4: Budget Justification
    res_just = SKILL_REGISTRY["budget_justification"].execute({
        "items": [
            {"category": "Personnel", "total_cost": 72000.0, "description": "2 Graduate Research Assistants", "justification": "Execute formal proofs and testbed code."},
            {"category": "Equipment", "total_cost": 38000.0, "description": "4x High-throughput GPU workstations", "justification": "Run local simulations and benchmarks."}
        ]
    })

    # Assignment 1: Multi-Claim Competing Research Sources
    res_multi_claim = SKILL_REGISTRY["multi_claim_synthesis"].execute({
        "articles": [
            {"title": "Paper A (IEEE 2024)", "claim": "Decentralized consensus is slower due to O(N^2) broadcast overhead.", "evidence_strength": "STRONG"},
            {"title": "Paper B (ACM 2025)", "claim": "Pipelined gossip protocols reduce latency by 34%, beating centralized coordinators.", "evidence_strength": "VERY_STRONG"}
        ]
    })

    # Assignment 2: Test Against Low-Evidence Input & Anti-Fabrication
    # Case A: Low evidence claim with zero citations -> Should be REJECTED
    res_low_evidence = SKILL_REGISTRY["low_evidence_rejection"].execute({
        "claim": "Quantum multi-agent computing achieves 10000x instantaneous speedup over classical algorithms.",
        "citations": []
    })

    # Case B: Verified claim with citations -> ACCEPTED
    res_verified_claim = SKILL_REGISTRY["low_evidence_rejection"].execute({
        "claim": "Decentralized consensus protocols improve fault tolerance by 42% over centralized coordinators.",
        "citations": ["Wooldridge et al. (2023)", "IEEE Trans. Cybernetics (2024)"]
    })

    return {
        "week": 3,
        "title": "Lab 3: Skill Creation -- Reusable AI Capabilities & Anti-Hallucination Constraints",
        "available_skills": list(SKILL_REGISTRY.keys()),
        "skill_outputs": {
            "summarization": res_summary,
            "funding_evaluation": res_funding_eval,
            "research_gaps": res_gaps,
            "budget_justification": res_just
        },
        "assignment_1_multi_claim_synthesis": res_multi_claim,
        "assignment_2_low_evidence_rejection": {
            "unsupported_claim_result": res_low_evidence,
            "verified_claim_result": res_verified_claim,
            "anti_fabrication_passed": res_low_evidence["status"] == "REJECTED" and res_verified_claim["status"] == "ACCEPTED"
        },
        "completed": True
    }

if __name__ == "__main__":
    result = run_lab_week03()
    print(json.dumps(result, indent=2))
